# =====================================================================
# Surbex Z 30s - Weekly Demand Forecasting (Train 118 weeks / Test 12 weeks)
# Runs in Google Colab. Models: Naive, Seasonal Naive, 4-wk SMA,
# SES (alpha 0.3 and 0.6), Holt-Winters.
# =====================================================================

# ---------------------------------------------------------------------
# BLOCK 0: Import the libraries we need
# ---------------------------------------------------------------------
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing

warnings.filterwarnings("ignore")          # keep the output clean
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 30)

# ---------------------------------------------------------------------
# BLOCK 1: Load the Excel file
# In Colab a file-picker pops up: choose Surbex_With_Split.xlsx.
# Outside Colab it just looks for the file in the current folder.
# ---------------------------------------------------------------------
try:
    from google.colab import files
    uploaded = files.upload()
    FILE_PATH = list(uploaded.keys())[0]
except ImportError:
    FILE_PATH = "Surbex_With_Split.xlsx"

SHEET_NAME = "surbex_z_weekly_demand"
try:
    df = pd.read_excel(FILE_PATH, sheet_name=SHEET_NAME)
except ValueError:
    # If the sheet has a different name, use the first sheet instead.
    print(f"Sheet '{SHEET_NAME}' not found - using the first sheet instead.")
    df = pd.read_excel(FILE_PATH, sheet_name=0)

df["Week_Start_Date"] = pd.to_datetime(df["Week_Start_Date"])
df = df.sort_values("Week_Start_Date").reset_index(drop=True)

# ---------------------------------------------------------------------
# BLOCK 2: Split into train_df and test_df using the "Set" column
# Then check the split is what we expect (118 train, 12 test, in time order).
# ---------------------------------------------------------------------
train_df = df[df["Set"] == "Train"].reset_index(drop=True)
test_df = df[df["Set"] == "Test"].reset_index(drop=True)

assert len(train_df) == 118 and len(test_df) == 12, "Expected 118 train and 12 test rows"
assert train_df["Week_Start_Date"].max() < test_df["Week_Start_Date"].min(), \
    "Train must come entirely before Test"

H = len(test_df)                 # forecast horizon = 12 weeks
SEASON = 52                      # weekly data, yearly season

# Everything the models are allowed to see is this one array:
y_train = train_df["Actual_Demand"].to_numpy(dtype=float)

# The test actuals are stored here but are ONLY used in Block 6 (scoring).
y_test = test_df["Actual_Demand"].to_numpy(dtype=float)

print(f"Train: {train_df['Week_Start_Date'].min().date()} to {train_df['Week_Start_Date'].max().date()} ({len(train_df)} weeks)")
print(f"Test : {test_df['Week_Start_Date'].min().date()} to {test_df['Week_Start_Date'].max().date()} ({len(test_df)} weeks)\n")

# ---------------------------------------------------------------------
# BLOCK 3: Simple forecasting functions
# Each function receives ONLY the training series (y_train) and the
# number of weeks to forecast (h). They never see the test data.
# ---------------------------------------------------------------------

def naive_forecast(y, h):
    """Naive: every future week = the last observed training week."""
    return np.repeat(y[-1], h)


def seasonal_naive_forecast(y, h, season=52):
    """Seasonal naive: each future week = the same week one season (52 weeks) earlier.
    Weeks 119..130 look back to weeks 67..78, which are all inside the training data."""
    n = len(y)
    return np.array([y[n - season + (i % season)] for i in range(h)])


def sma_forecast(y, h, window=4):
    """Simple moving average: average of the last 4 training weeks, held flat.
    (Forecasting further ahead would need forecasts, not actuals, so a flat line is used.)"""
    return np.repeat(y[-window:].mean(), h)


def ses_forecast(y, h, alpha):
    """Simple exponential smoothing with a fixed alpha.
    Level update: level = alpha * today + (1 - alpha) * previous level.
    The final level (from training data only) is the flat forecast for all h weeks."""
    level = y[0]
    for value in y[1:]:
        level = alpha * value + (1 - alpha) * level
    return np.repeat(level, h)

# ---------------------------------------------------------------------
# BLOCK 4: Holt-Winters (seasonal) - fitted on training data only
#
# NOTE ABOUT Event_Flag:
#   Standard Holt-Winters has no place to put an outside variable like
#   Event_Flag (it only uses the demand history: level, trend, season).
#   What I did instead: the dengue / post-monsoon event happens in the SAME
#   calendar weeks every year, so the 52-week SEASONAL component of
#   Holt-Winters learns that spike by itself from the 2 years of training data.
#   I did NOT feed in the Event_Flag values from test_df, because the rules
#   say no test_df values may be used in any forecast.
#
# Trend "if justified": I fit several Holt-Winters versions (no trend, trend,
# damped trend; additive or multiplicative season) and keep the one with the
# lowest AICc computed on the TRAINING data. AICc penalises extra parameters,
# so a trend is only kept if it truly improves the fit.
# ---------------------------------------------------------------------
candidates = []
for trend, damped in [(None, False), ("add", False), ("add", True)]:
    for seasonal in ["add", "mul"]:
        try:
            model = ExponentialSmoothing(
                y_train,
                trend=trend,
                damped_trend=damped,
                seasonal=seasonal,
                seasonal_periods=SEASON,
                initialization_method="heuristic",   # needs >= 2 full seasons (we have 118 weeks)
            )
            fit = model.fit(optimized=True)
            candidates.append({
                "Trend": "none" if trend is None else ("damped" if damped else "additive"),
                "Season": seasonal,
                "AICc": fit.aicc,
                "Train_SSE": fit.sse,
                "_fit": fit,
            })
        except Exception as e:
            print(f"Skipped a Holt-Winters candidate ({trend}, damped={damped}, {seasonal}): {e}")

cand_table = pd.DataFrame(candidates).sort_values("AICc").reset_index(drop=True)
print("Holt-Winters candidates (ranked by training AICc, lower is better):")
print(cand_table[["Trend", "Season", "AICc", "Train_SSE"]].round(1).to_string(index=False))

best_hw = cand_table.iloc[0]
hw_fit = best_hw["_fit"]
hw_label = f"Holt-Winters (trend={best_hw['Trend']}, season={best_hw['Season']})"
print(f"\nChosen: {hw_label}\n")

hw_forecast = np.asarray(hw_fit.forecast(H))     # 12-step-ahead forecast, no test data used

# ---------------------------------------------------------------------
# BLOCK 5: Produce all forecasts for the 12 test weeks
# ---------------------------------------------------------------------
forecasts = {
    "Naive": naive_forecast(y_train, H),
    "Seasonal Naive (52)": seasonal_naive_forecast(y_train, H, SEASON),
    "SMA (4-wk)": sma_forecast(y_train, H, 4),
    "SES (alpha=0.3)": ses_forecast(y_train, H, 0.3),
    "SES (alpha=0.6)": ses_forecast(y_train, H, 0.6),
    hw_label: hw_forecast,
}

# ---------------------------------------------------------------------
# BLOCK 6: Error metrics on the 12 test weeks
# Error = Actual - Forecast (positive = we under-forecast)
# ---------------------------------------------------------------------
def evaluate(actual, forecast):
    err = actual - forecast
    mad = np.mean(np.abs(err))                          # Mean Absolute Deviation
    mape = np.mean(np.abs(err) / actual) * 100          # Mean Absolute % Error
    rmse = np.sqrt(np.mean(err ** 2))                   # Root Mean Squared Error
    wape = np.sum(np.abs(err)) / np.sum(actual) * 100   # Weighted Absolute % Error
    bias = np.mean(err)                                 # average error (direction)
    rsfe = np.sum(err)                                  # Running Sum of Forecast Errors
    ts = rsfe / mad                                     # Tracking Signal
    return {"MAD": mad, "MAPE_%": mape, "RMSE": rmse, "WAPE_%": wape,
            "Bias": bias, "RSFE": rsfe, "Tracking_Signal": ts}

results = pd.DataFrame({name: evaluate(y_test, f) for name, f in forecasts.items()}).T

# ---------------------------------------------------------------------
# BLOCK 7: Print the results
# ---------------------------------------------------------------------
# (a) Model comparison table (sorted by MAPE; change RANK_BY to rank differently)
RANK_BY = "MAPE_%"
results_sorted = results.sort_values(RANK_BY)
print("=" * 90)
print("(a) MODEL COMPARISON - 12 test weeks (Error = Actual - Forecast)")
print("=" * 90)
print(results_sorted.round(2).to_string())

best_model = results_sorted.index[0]
print(f"\nBest model by {RANK_BY}: {best_model}")

# (b) Week-by-week table: actual and every model's forecast
weekly = pd.DataFrame({"Week_Start_Date": test_df["Week_Start_Date"].dt.date,
                       "Actual": y_test})
for name, f in forecasts.items():
    weekly[name] = np.round(f, 0)
print("\n" + "=" * 90)
print("(b) TEST WEEKS: ACTUAL vs FORECASTS")
print("=" * 90)
print(weekly.to_string(index=False))

# (c) Five largest absolute misses for the best model
best_f = forecasts[best_model]
misses = pd.DataFrame({
    "Week_Start_Date": test_df["Week_Start_Date"].dt.date,
    "Actual": y_test,
    "Forecast": np.round(best_f, 0),
    "Error (A-F)": np.round(y_test - best_f, 0),
    "Abs_Error": np.round(np.abs(y_test - best_f), 0),
    "Abs_%_Error": np.round(np.abs(y_test - best_f) / y_test * 100, 1),
})
top5 = misses.sort_values("Abs_Error", ascending=False).head(5)
print("\n" + "=" * 90)
print(f"(c) FIVE LARGEST ABSOLUTE MISSES - {best_model}")
print("=" * 90)
print(top5.to_string(index=False))

# ---------------------------------------------------------------------
# BLOCK 8: Plot every forecast against the actual test values
# ---------------------------------------------------------------------
plt.figure(figsize=(12, 6))
plt.plot(test_df["Week_Start_Date"], y_test, color="black", linewidth=3,
         marker="o", label="Actual")
styles = ["--", "-.", ":", "--", "-.", "-"]
for (name, f), ls in zip(forecasts.items(), styles):
    plt.plot(test_df["Week_Start_Date"], f, linestyle=ls, marker=".", linewidth=1.8, label=name)
plt.title("Surbex Z 30s - Test-Period Forecasts vs Actual Demand (12 weeks)")
plt.xlabel("Week start date")
plt.ylabel("Packs per week")
plt.grid(alpha=0.3)
plt.legend(loc="best", fontsize=9)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------------------
# BLOCK 9: Data-leakage statement
# ---------------------------------------------------------------------
print("\n" + "=" * 90)
print("HOW DATA LEAKAGE WAS AVOIDED")
print("=" * 90)
print("""1. The split came from the 'Set' column and was checked: all train dates come before all test dates.
2. Every model function and the Holt-Winters fit received ONLY y_train (the 118 training weeks).
3. y_test (test Actual_Demand) was used in one place only: scoring the forecasts in the metrics step.
4. No recursive forecast used test actuals. Multi-step forecasts are flat lines (Naive, SMA, SES),
   a look-back inside the training data (Seasonal Naive), or Holt-Winters' own 12-step forecast.
5. Holt-Winters settings (trend / season type) were chosen by AICc on training data, not by test performance.
6. Event_Flag and all other test_df columns (including the test weeks' Event_Flag) were not used by any model.""")

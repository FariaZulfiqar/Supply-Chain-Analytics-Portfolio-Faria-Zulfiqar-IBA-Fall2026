# -*- coding: utf-8 -*-
"""
MGT-353 | Company-Calibrated Synthetic Dataset for Academic Analysis
Surbex-Z 30s weekly series (120 weeks).  Reproducible: SEED = 353, single run.
All parameters below were fixed BEFORE any series was generated.
Dependencies: numpy, pandas, openpyxl.
"""
import numpy as np, pandas as pd, json, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.formula import ArrayFormula
from openpyxl.formatting.rule import FormulaRule

OUT = sys.argv[1] if len(sys.argv) > 1 else "MGT353_SurbexZ_Synthetic_Dataset_v1.0.xlsx"

LABEL = ("Company-Calibrated Synthetic Dataset for Academic Analysis \u2014 illustrative figures, "
         "calibrated to Abbott Laboratories (Pakistan) Limited's disclosed scale, not actual company records.")

# ----------------------------------------------------------------------------------
# 0. PRE-REGISTERED PARAMETERS (fixed before generation)
# ----------------------------------------------------------------------------------
SEED = 353
N, N_TRAIN = 120, 108
START = "2024-03-11"
PRODUCT = "Surbex-Z 30s"
BASE0 = 52000            # synthetic baseline demand (packs / week) at week 0
TREND = 0.0004           # log-trend per week (~2.1% per year)
SEAS_AMP, SEAS_PEAK_DOY = 0.025, 45
PRICE_REF, PRICE_ELAS = 420.0, -0.10
PRICE_REGIMES = [(1, "2024-03-11", 385), (2, "2024-07-01", 420), (3, "2025-04-07", 458), (4, "2026-01-12", 490)]
PROMO_START_P, PROMO_DEPTHS, PROMO_DEPTH_P = 0.16, [0.05, 0.075, 0.10, 0.15], [0.35, 0.30, 0.25, 0.10]
PROMO_UP_BASE, PROMO_UP_SLOPE, PROMO_UP_SD = 0.03, 0.20, 0.035
EVENT_ISO_WEEKS = (38, 46)
EVENT_YR_MEAN, EVENT_YR_SD, EVENT_WK_SD = 0.12, 0.05, 0.04
MKT_MEDIAN0, MKT_DRIFT, MKT_PHI, MKT_INNOV = 1.9e6, 0.04, 0.55, 0.22
MKT_PROMO, MKT_EVENT, MKT_BURST_P, MKT_BURST = 0.12, 0.07, 0.06, 0.35
MKT_ELAS = 0.03
NOISE_PHI, NOISE_SD, NOISE_DF = 0.40, 0.06, 7
STOCK_START_P, STOCK_DUR1_P, STOCK_GAP = 0.03, 0.70, 2
FILL_A, FILL_B, FILL_B_EVENT = (6, 3), None, (4, 4)
REBOUND_MEAN, REBOUND_SD = 0.04, 0.03
EXC = [  # (label, start, n_weeks, [(mean, sd) per week])
    ("Distribution disruption (synthetic)", "2024-09-02", 2, [(-0.20, 0.05), (-0.08, 0.04)]),
    ("Batch-release supply interruption (synthetic)", "2025-02-10", 1, [(0.0, 0.0)]),  # effect via forced stockout
    ("Public-health advisory demand surge (synthetic)", "2026-02-09", 2, [(0.14, 0.05), (0.09, 0.04)]),
]
FC_WINDOW, FC_INIT = 4, 52000
BOUNDS = dict(dem=(20000, 100000), price=(300, 700), mkt=(300000, 10000000), depth_max=0.20)
CORR_THR, VIF_THR, SMALL_N = 0.70, 5.0, 10

# ----------------------------------------------------------------------------------
# 1. DATA GENERATION (single run)
# ----------------------------------------------------------------------------------
rng = np.random.default_rng(SEED)
dates = pd.date_range(START, periods=N, freq="7D")
wk = np.arange(1, N + 1)
assert (dates.dayofweek == 0).all() and len(dates) == 120
assert dates[N_TRAIN - 1] == pd.Timestamp("2026-03-30") and dates[N_TRAIN] == pd.Timestamp("2026-04-06") \
    and dates[-1] == pd.Timestamp("2026-06-22")

# price regimes
rstart = [pd.Timestamp(s) for _, s, _ in PRICE_REGIMES]
assert all(d.dayofweek == 0 for d in rstart)
regime = np.zeros(N, int); price = np.zeros(N)
for i, d in enumerate(dates):
    k = max(j for j, s in enumerate(rstart) if d >= s)
    regime[i] = PRICE_REGIMES[k][0]; price[i] = PRICE_REGIMES[k][2]

# promotions
promo = np.zeros(N, int); depth = np.zeros(N)
t, cool = 0, 0
while t < N:
    if cool > 0:
        cool -= 1; t += 1; continue
    if rng.random() < PROMO_START_P:
        dur = 1 if rng.random() < 0.6 else 2
        d_ = rng.choice(PROMO_DEPTHS, p=PROMO_DEPTH_P)
        for k in range(dur):
            if t + k < N: promo[t + k] = 1; depth[t + k] = d_
        t += dur; cool = 1
    else:
        t += 1

# recurring seasonal event flag
isow = dates.isocalendar().week.to_numpy().astype(int)
event = ((isow >= EVENT_ISO_WEEKS[0]) & (isow <= EVENT_ISO_WEEKS[1])).astype(int)
ev_years = sorted(set(dates[event == 1].year))
yr_eff = {y: rng.normal(EVENT_YR_MEAN, EVENT_YR_SD) for y in ev_years}
ev_wk_noise = rng.normal(0, EVENT_WK_SD, N)
event_eff = np.array([event[i] * (yr_eff[dates[i].year] + ev_wk_noise[i]) if event[i] else 0.0 for i in range(N)])

# marketing
mu = np.log(MKT_MEDIAN0) + MKT_DRIFT * wk / 52
x = np.zeros(N); prev = rng.normal(0, MKT_INNOV / np.sqrt(1 - MKT_PHI ** 2))
for i in range(N):
    prev = MKT_PHI * prev + rng.normal(0, MKT_INNOV); x[i] = prev
burst = np.zeros(N); t = 0
while t < N:
    if rng.random() < MKT_BURST_P:
        dur = 1 if rng.random() < 0.6 else 2
        burst[t:t + dur] = MKT_BURST; t += dur + 1
    else:
        t += 1
logm = mu + x + MKT_PROMO * promo + MKT_EVENT * event + burst
mkt = np.round(np.exp(logm), -4)

# exceptional events
exc_label = np.array(["None"] * N, dtype=object); exc_eff = np.zeros(N); exc_idx = {}
for lab, s, nw, effs in EXC:
    i0 = int(np.where(dates == pd.Timestamp(s))[0][0]); exc_idx[lab] = (i0, nw)
    for k in range(nw):
        exc_label[i0 + k] = lab
        m, sd = effs[k]; exc_eff[i0 + k] = rng.normal(m, sd) if sd > 0 else 0.0

# latent variation / noise
eps = rng.standard_t(NOISE_DF, size=N) * NOISE_SD / np.sqrt(NOISE_DF / (NOISE_DF - 2))
noise = np.zeros(N)
for i in range(N):
    noise[i] = (NOISE_PHI * noise[i - 1] if i > 0 else 0.0) + eps[i]
promo_noise = rng.normal(0, 1, N)
promo_eff = promo * (PROMO_UP_BASE + PROMO_UP_SLOPE * depth + PROMO_UP_SD * promo_noise)
doy = dates.dayofyear.to_numpy()
season = SEAS_AMP * np.cos(2 * np.pi * (doy - SEAS_PEAK_DOY) / 365.25)
lat_log = (np.log(BASE0) + TREND * wk + season + PRICE_ELAS * np.log(price / PRICE_REF)
           + promo_eff + event_eff + MKT_ELAS * (logm - np.log(MKT_MEDIAN0)) + exc_eff + noise)

# stockouts
stock = np.zeros(N, int); t = 0
while t < N:
    if rng.random() < STOCK_START_P:
        dur = 1 if rng.random() < STOCK_DUR1_P else 2
        stock[t:t + dur] = 1; t += dur + STOCK_GAP
    else:
        t += 1
iB, _ = exc_idx["Batch-release supply interruption (synthetic)"]
stock[iB] = 1
fill = rng.beta(FILL_A[0], FILL_A[1], size=N)
fill[iB] = rng.beta(FILL_B_EVENT[0], FILL_B_EVENT[1])
rebound_draw = rng.normal(REBOUND_MEAN, REBOUND_SD, N)
rebound = np.zeros(N)
for i in range(1, N):
    if stock[i - 1] == 1 and stock[i] == 0: rebound[i] = rebound_draw[i]
latent = np.exp(lat_log + rebound)                     # pre-stockout latent demand (NOT saved in workbook)
actual = np.rint(np.where(stock == 1, latent * fill, latent)).astype(int)
assert (actual > 0).all()

# historical forecast: 4-week trailing mean of PRIOR observed demand; init = FC_INIT
def make_forecast(a):
    f = np.zeros(len(a), int)
    for i in range(len(a)):
        f[i] = FC_INIT if i == 0 else int(np.floor(np.mean(a[max(0, i - FC_WINDOW):i]) + 0.5))
    return f
fcst = make_forecast(actual)

# leakage perturbation test: changing actual[t:] must not change forecast[:t+1]
leak_pass = 0
for tt in range(N):
    a2 = actual.copy(); a2[tt:] = a2[tt:] + rng.integers(1, 5000, size=N - tt)
    if (make_forecast(a2)[:tt + 1] == fcst[:tt + 1]).all(): leak_pass += 1
assert leak_pass == N

split = np.where(wk <= N_TRAIN, "Train", "Holdout")
df = pd.DataFrame({
    "Week_Start_Date": dates, "Product_or_Category": PRODUCT, "Actual_Demand": actual, "Historical_Forecast": fcst,
    "Price": price.astype(int), "Promo_Flag": promo, "Promo_Depth": depth, "Event_Flag": event,
    "Marketing_Spend": mkt.astype(int), "Stockout_Flag": stock, "Exceptional_Event": exc_label,
    "Data_Split": split, "Week_Number": wk, "Price_Regime_ID": regime})

# ----------------------------------------------------------------------------------
# 2. WORKBOOK
# ----------------------------------------------------------------------------------
FN = "Arial"
f_norm = Font(name=FN, size=10); f_bold = Font(name=FN, size=10, bold=True)
f_hdr = Font(name=FN, size=10, bold=True, color="FFFFFF"); f_title = Font(name=FN, size=14, bold=True, color="1F3864")
f_in = Font(name=FN, size=10, color="0000FF"); f_ital = Font(name=FN, size=9, italic=True, color="595959")
fill_hdr = PatternFill("solid", fgColor="1F3864"); fill_adm = PatternFill("solid", fgColor="7F7F7F")
fill_calc = PatternFill("solid", fgColor="2E75B6"); fill_lab = PatternFill("solid", fgColor="FFF2CC")
fill_sec = PatternFill("solid", fgColor="D9E1F2"); fill_warn = PatternFill("solid", fgColor="FFEB9C")
fill_pass = PatternFill("solid", fgColor="C6EFCE"); fill_fail = PatternFill("solid", fgColor="FFC7CE")
thin = Side(style="thin", color="BFBFBF"); box = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top")

wb = Workbook()
names = ["README", "Synthetic_Data", "Data_Dictionary", "Assumption_Log", "Data_Audit",
         "Summary_Stats", "Event_Log", "Forecast_Setup", "Regression_Readiness"]
ws_ = {}
for i, n in enumerate(names):
    ws_[n] = wb.active if i == 0 else wb.create_sheet(n)
    ws_[n].title = n
    ws_[n].sheet_view.showGridLines = False
RM, SD, DD, AL, DA, SS, EL, FS, RR = [ws_[n] for n in names]

def put(ws, ref, v, font=f_norm, fill=None, fmt=None, wrap=True, border=False, align=None):
    c = ws[ref]; c.value = v; c.font = font
    if fill: c.fill = fill
    if fmt: c.number_format = fmt
    c.alignment = align or (WRAP if wrap else Alignment(vertical="top"))
    if border: c.border = box
    return c

def header_row(ws, row, labels, col0=1, fill=fill_hdr):
    for j, lab in enumerate(labels):
        put(ws, f"{chr(64 + col0 + j)}{row}", lab, f_hdr, fill, border=True, align=Alignment(wrap_text=True, vertical="center"))

def widths(ws, ws_w):
    for k, v in ws_w.items(): ws.column_dimensions[k].width = v

# range helpers on Synthetic_Data (banner row 1, header row 2, data rows 3..122)
R0, RN, RT = 3, 122, 110      # first row, last row, last training row
RH = RT + 1                   # first holdout row
def rg(col, a=R0, b=RN): return f"Synthetic_Data!${col}${a}:${col}${b}"
ALL, TR, HO = (R0, RN), (R0, RT), (RH, RN)
COL = dict(date="A", prod="B", dem="C", fc="D", price="E", pf="F", pd="G", ef="H", mk="I", sf="J", ex="K",
           split="L", wk="M", reg="N", mg="O")

# ===== Fixed cross-sheet anchors =====
SS_THR = "Summary_Stats!$B$5"
AUDIT_OVERALL = "Data_Audit!$B$43"

# ----------------------------------------------------------------------------------
# Synthetic_Data
# ----------------------------------------------------------------------------------
put(SD, "A1", LABEL, Font(name=FN, size=10, bold=True, color="7F6000"), fill_lab, wrap=False)
for j in range(2, 16): SD.cell(row=1, column=j).fill = fill_lab
SD.row_dimensions[1].height = 18
req = ["Week_Start_Date", "Product_or_Category", "Actual_Demand", "Historical_Forecast", "Price", "Promo_Flag",
       "Promo_Depth", "Event_Flag", "Marketing_Spend", "Stockout_Flag", "Exceptional_Event"]
adm = ["Data_Split", "Week_Number", "Price_Regime_ID"]; calc = ["Marketing_Group"]
for j, h in enumerate(req + adm + calc):
    fl = fill_hdr if j < 11 else (fill_adm if j < 14 else fill_calc)
    put(SD, f"{chr(65 + j)}2", h, f_hdr, fl, border=True, align=Alignment(wrap_text=True, vertical="center"))
for i, r in df.iterrows():
    row = R0 + i
    vals = [r.Week_Start_Date.to_pydatetime(), r.Product_or_Category, int(r.Actual_Demand), int(r.Historical_Forecast),
            int(r.Price), int(r.Promo_Flag), float(r.Promo_Depth), int(r.Event_Flag), int(r.Marketing_Spend),
            int(r.Stockout_Flag), r.Exceptional_Event, r.Data_Split, int(r.Week_Number), int(r.Price_Regime_ID)]
    fm = ["dd-mmm-yyyy", None, "#,##0", "#,##0", "#,##0", "0", "0.0%", "0", "#,##0", "0", None, None, "0", "0"]
    for j, (v, f) in enumerate(zip(vals, fm)):
        c = SD.cell(row=row, column=j + 1, value=v); c.font = f_norm
        if f: c.number_format = f
    c = SD.cell(row=row, column=15, value=f'=IF(I{row}<={SS_THR},"Low","High")'); c.font = f_norm
tab = Table(displayName="tblSurbexZ", ref=f"A2:O{RN}")
tab.tableStyleInfo = TableStyleInfo(name="TableStyleLight1", showRowStripes=False)
SD.add_table(tab)
SD.freeze_panes = "B3"
widths(SD, dict(A=15, B=19, C=15, D=18, E=10, F=11, G=12, H=11, I=17, J=13, K=44, L=12, M=13, N=16, O=16))
SD.row_dimensions[2].height = 30
rng_all = f"A{R0}:O{RN}"
SD.conditional_formatting.add(f"J{R0}:J{RN}", FormulaRule(formula=[f"$J{R0}=1"], fill=fill_fail))
SD.conditional_formatting.add(f"F{R0}:G{RN}", FormulaRule(formula=[f"$F{R0}=1"], fill=fill_pass))
SD.conditional_formatting.add(f"H{R0}:H{RN}", FormulaRule(formula=[f"$H{R0}=1"], fill=PatternFill("solid", fgColor="DDEBF7")))
SD.conditional_formatting.add(f"K{R0}:K{RN}", FormulaRule(formula=[f'$K{R0}<>"None"'], fill=fill_warn))
SD.conditional_formatting.add(f"L{R0}:L{RN}", FormulaRule(formula=[f'$L{R0}="Holdout"'], fill=PatternFill("solid", fgColor="D9D9D9")))
SD.oddHeader.center.text = "Synthetic dataset \u2014 not actual Abbott records"
SD.oddFooter.center.text = LABEL

# ----------------------------------------------------------------------------------
# Data_Dictionary
# ----------------------------------------------------------------------------------
put(DD, "A1", "Data Dictionary \u2014 Synthetic_Data sheet (15 columns)", f_title, wrap=False)
put(DD, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
put(DD, "A3", "Colour legend: dark-blue headers = required fields; grey = administrative fields; mid-blue = calculated field. "
    "Blue font in other sheets = hard-coded input/assumption; black = formula.", f_ital, wrap=False)
dd_head = ["Column_Name", "Definition", "Data_Type", "Unit", "Valid_Values_or_Range", "How_Generated",
           "Field_Nature", "Interpretation", "Limitations"]
header_row(DD, 5, dd_head)
dd = [
 ("Week_Start_Date", "Monday on which the observation week begins.", "Date", "Calendar date (dd-mmm-yyyy)",
  "120 consecutive Mondays, 11-Mar-2024 to 22-Jun-2026", "Computed programmatically: start date + 7-day steps.", "Administrative (calculated)",
  "Identifies the week; one row per week.", "Week is Monday\u2013Sunday by assumption."),
 ("Product_or_Category", "Product identifier. Constant.", "Text", "n/a", "Surbex-Z 30s", "Constant.", "Administrative",
  "Single product, single pack size (30 tablets).", "Not an actual Abbott SKU record."),
 ("Actual_Demand", "SYNTHETIC OBSERVED sales / fulfilled packs in the week, AFTER stockout suppression. NOT unconstrained customer demand.",
  "Integer", "Packs (30-tablet)", "Positive integer; pre-registered plausible range 20,000\u2013100,000",
  "Latent log-demand = baseline + trend + background seasonality + price + promotion + event + marketing + exceptional + AR(1) noise; "
  "in stockout weeks multiplied by a random fill ratio; rounded to whole packs.", "Observed (synthetic)",
  "Use as the forecasting/regression target. In stockout weeks it understates what customers would have bought.",
  "Lost sales are NOT measured and cannot be recovered exactly. Not an actual Abbott record."),
 ("Historical_Forecast", "Synthetic benchmark forecast issued BEFORE the week: trailing mean of the previous 4 weeks of Actual_Demand.",
  "Integer", "Packs", "Positive integer", "Week 1 = assumed prior planning figure 52,000; weeks 2\u20134 = mean of all prior weeks; week t>=5 = round-half-up mean of weeks t-4..t-1. "
  "No stockout/exception adjustment. Same rule in holdout (one-step-ahead).", "Synthetic (calculated, leakage-free)",
  "A naive operational benchmark. Not a method Abbott actually used.", "Uses prior observed (stockout-affected) demand; one-step-ahead, not a 12-week horizon forecast."),
 ("Price", "Illustrative printed maximum retail price (MRP) per 30-tablet pack, PKR.", "Integer", "PKR per pack",
  "385, 420, 458, 490 (4 regimes)", "Four stable regimes with effective dates in Assumption_Log; no weekly price changes.", "Synthetic",
  "Regulated-price proxy. Changes are infrequent step changes.", "Not a verified actual price or DRAP approval. Price is confounded with time (steps rise over the sample); interpret any coefficient as an association."),
 ("Promo_Flag", "1 = promotional (trade-incentive) week, 0 = otherwise.", "Integer (0/1)", "Indicator", "0 or 1",
  "Stochastic campaign process (start prob 0.16/eligible week, 1\u20132 week campaigns, 1-week cooldown).", "Synthetic",
  "Promotions modelled as trade/bonus schemes; printed MRP is unchanged.", "Realised rate documented in Summary_Stats; not forced to a target."),
 ("Promo_Depth", "Promotional depth as a DECIMAL PROPORTION of MRP-equivalent value given as trade incentive (0.05 = 5%).", "Decimal", "Proportion (displayed as %)",
  "0 when Promo_Flag=0; one of 0.05, 0.075, 0.10, 0.15 when Promo_Flag=1", "Drawn per campaign; constant within a campaign.", "Synthetic",
  "Single convention: decimal proportion (never percentage points).", "Strongly collinear with Promo_Flag by construction \u2014 do not include both in one regression."),
 ("Event_Flag", "1 = recurring seasonal health-pressure window (post-monsoon / dengue-awareness illness season), 0 = otherwise.", "Integer (0/1)", "Indicator", "0 or 1",
  "Calendar rule: ISO weeks 38\u201346 (mid-Sep to mid-Nov) of each year.", "Synthetic (rule-based)",
  "Scenario assumption of seasonal demand pressure (assumed uplift mean ~12%, variable).", "Not evidence that such events raised actual Surbex-Z demand. Holdout (Apr\u2013Jun 2026) contains no event weeks."),
 ("Marketing_Spend", "Illustrative weekly marketing/promotional spend, PKR.", "Integer", "PKR per week",
  "Pre-registered range 300,000\u201310,000,000", "Log-AR(1) around ~PKR 1.9m with mild drift, partial links to promo/event, random bursts; rounded to PKR 10,000.", "Synthetic",
  "Candidate regressor; not a copy of demand, promo or time.", "Not Abbott's actual budget."),
 ("Stockout_Flag", "1 = a (synthetic) stockout occurred in the week, 0 = otherwise.", "Integer (0/1)", "Indicator", "0 or 1",
  "Random episodes (start prob 0.03/week, 1\u20132 weeks) plus the week of the batch-release interruption.", "Synthetic",
  "Observed Actual_Demand is suppressed by a random fill ratio (Beta(6,3), mean ~0.67) in flagged weeks.", "True unconstrained demand / lost sales are unknown and not provided."),
 ("Exceptional_Event", "Label of a one-off synthetic event (1\u20132 weeks) or 'None'.", "Text", "n/a",
  "None; or one of 3 labels listed in Event_Log", "Dates fixed in advance (see Assumption_Log A22).", "Synthetic",
  "Distinct from recurring Event_Flag windows.", "Not verified Abbott incidents."),
 ("Data_Split", "Train = weeks 1\u2013108; Holdout = weeks 109\u2013120.", "Text", "n/a", "Train / Holdout", "Assigned by position and date only.", "Administrative",
  "Fit and select models on Train only; Holdout is for later out-of-sample evaluation.", "None."),
 ("Week_Number", "Sequential week index 1\u2013120.", "Integer", "Week", "1\u2013120", "Computed.", "Administrative", "Time index.", "Do not use as a hidden trend regressor without disclosure."),
 ("Price_Regime_ID", "Identifier of the price regime in force (1\u20134).", "Integer", "n/a", "1, 2, 3, 4", "Lookup from regime start dates.", "Administrative", "Grouping variable for price comparisons.", "Regime 4 spans the end of training and the full holdout."),
 ("Marketing_Group", "Low if Marketing_Spend <= TRAINING-period median, High otherwise.", "Text", "n/a", "Low / High",
  "Formula referencing Summary_Stats!B5 (median of weeks 1\u2013108). Ties with the median are assigned to Low.", "Calculated",
  "Pre-defined descriptive grouping (rule fixed before comparing demand).", "Association only; not causal."),
]
for i, rowv in enumerate(dd):
    for j, v in enumerate(rowv): put(DD, f"{chr(65 + j)}{6 + i}", v, border=True)
put(DD, "A22", "Key definitions", f_bold, fill_sec)
put(DD, "A23", "Observed vs unconstrained demand: Actual_Demand is observed synthetic sales/fulfilled packs. During stockouts customers may have wanted more; "
    "the dataset does not reveal by how much. A latent pre-stockout series was used internally for generation but is deliberately NOT included, so lost sales cannot be recovered.", wrap=False)
put(DD, "A24", "Price basis: illustrative printed MRP per 30-tablet pack in PKR. Promo_Depth convention: decimal proportion (0.10 = 10%) of MRP-equivalent trade incentive; Price itself does not change in promotional weeks.", wrap=False)
widths(DD, dict(A=20, B=44, C=12, D=18, E=30, F=52, G=18, H=40, I=44))

# ----------------------------------------------------------------------------------
# Assumption_Log (+ parameter register + price-regime input table)
# ----------------------------------------------------------------------------------
put(AL, "A1", "Assumption Log", f_title, wrap=False)
put(AL, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
al_head = ["Assumption_ID", "Variable_or_Topic", "Assumption", "Rationale", "Source_or_Basis", "Verification_Category",
           "How_Implemented", "Expected_Analytical_Implications", "Limitations"]
header_row(AL, 4, al_head)
PUB, CTX, SYN = "Publicly verified", "Contextually supported", "Purely synthetic"
A = [
 ("A01", "Company calibration context", "Abbott Pakistan FY2025 net sales (PKR 75.40bn) is used ONLY as context for the scale of the company. It is NOT product revenue and is not used in any formula or generation step.",
  "Prompt requires company-level revenue never be represented as Surbex-Z revenue.", "README sources S3\u2013S5", "Reported publicly (secondary); NOT independently verified at original source",
  "No numerical use.", "None on data values.", "Net-sales line in the audited financial statements could not be opened (document retrieval truncated before the financial pages)."),
 ("A02", "Fiscal year-end", "Fiscal year ends 31 December.", "Verified from primary documents (PSX filing titles; annual report dates).", "README S1, S2", PUB, "Documentation only.", "None.", "None."),
 ("A03", "Product positioning", "Surbex-Z treated as an established, high-volume vitamin brand with steady demand.", "Annual Report 2025 describes Surbex Z as the no.1 Vitamin B complex brand (IQVIA MAT Dec 2025).", "README S1 (p.18)", PUB + " (qualitative only)",
  "Motivates stable baseline, modest trend and moderate noise.", "Supports a forecastable but uncertain series.", "No product volumes, prices or revenues are disclosed publicly in the sources used."),
 ("A04", "Demand scale", "Baseline synthetic demand of 52,000 packs/week at week 0 (~2.7m packs/yr).", "Round-number scale large enough to support a meaningful 12-week supply decision (~0.6m packs per horizon). Chosen as a teaching scale; NOT derived from company revenue.", "Design choice", SYN,
  "BASE0 = 52,000 in the generation script.", "Sets magnitude of safety-stock / commitment trade-offs.", "Not Abbott's actual volume."),
 ("A05", "Trend", "Modest upward log-trend of 0.04% per week (~2.1% per year).", "Established brand in an inflationary, growing market; deliberately small.", "Design choice (pre-registered)", SYN, "TREND = 0.0004.", "Trend model may or may not help.", "Direction/magnitude not tuned to any forecast result."),
 ("A06", "Background seasonality", "Mild annual cosine, amplitude 2.5%, peak near day-of-year 45.", "Gentle winter-leaning seasonality independent of Event_Flag.", "Design choice", SYN, "SEAS_AMP = 0.025.", "Seasonal methods are only weakly justified.", "Only ~2.3 annual cycles in the sample."),
 ("A07", "Noise", "AR(1) log-noise (phi 0.40) with scaled Student-t(7) innovations, sd 0.06.", "Natural week-to-week variation with occasional larger shocks.", "Design choice", SYN, "NOISE_PHI/NOISE_SD/NOISE_DF.", "Retains forecast uncertainty.", "Fat tails are synthetic."),
 ("A08", "Pricing (regulatory context)", "Pharmaceutical prices in Pakistan are regulated (Federal Government fixes MRP via DRAP; 2018 Drug Pricing Policy links increases to CPI; prices of non-essential drugs outside the NEML were deregulated in Feb 2024).",
  "Price must not move weekly; long stable regimes with occasional step changes.", "README S6 (official SRO 595(I)/2023); S7, S8, S9 (secondary)", CTX, "Used to justify long regimes.", "Price effects are weak and confounded with time.", "Secondary sources not verified against the original 2024 notification."),
 ("A09", "Price regimes", "Four regimes: R1 385 (11-Mar-2024), R2 420 (01-Jul-2024), R3 458 (07-Apr-2025), R4 490 (12-Jan-2026). Steps: +9.1%, +9.0%, +7.0%.", "Annual-ish CPI-linked increases of <= ~10% consistent with the non-essential-drug cap described in secondary sources.", "Assumption (input table below)", SYN,
  "Lookup of week date against regime start dates; audited by formula.", "Price coefficient likely confounded with trend.", "NOT actual Abbott prices or DRAP approvals."),
 ("A10", "Pricing (classification)", "Surbex-Z is ASSUMED to fall outside the National Essential Medicines List (price changes firm-initiated with notice, but kept sticky).", "Multivitamin; plausible but unverified.", "Assumption", SYN, "Documentation.", "Explains annual-ish step changes.", "If Surbex-Z were in the NEML its pricing would be more tightly controlled."),
 ("A11", "Price basis", "Price = printed MRP per 30-tablet pack in PKR; unchanged during promotions.", "Single consistent definition.", "Assumption", SYN, "Price column.", "Promotions act through trade incentives, not MRP.", "Retail/trade price differences ignored."),
 ("A12", "Price effect on demand", "Weak negative log-elasticity of -0.10 relative to PKR 420.", "Branded vitamin; inelastic, prescription-driven. Not tuned for significance.", "Design choice", SYN, "PRICE_ELAS = -0.10.", "Price coefficient is an association, not causal elasticity.", "Price rises monotonically with time (collinearity)."),
 ("A13", "Promotions (frequency)", "Campaigns start with probability 0.16 per eligible week, last 1\u20132 weeks, followed by a 1-week cooldown. Starting design target 15\u201320%; final realised rate is in Summary_Stats and was not forced.", "Pharma trade schemes are periodic but not FMCG-style frequent.", "Design choice", SYN, "Sequential stochastic loop.", "Allows promo vs non-promo comparison.", "Rate is whatever the seeded process produced."),
 ("A14", "Promotions (depth)", "Promo_Depth is a decimal proportion; values 0.05/0.075/0.10/0.15 with probs .35/.30/.25/.10; 0 if no promotion.", "Modest trade incentives.", "Design choice", SYN, "Per-campaign draw.", "Promo_Depth ~ Promo_Flag collinear.", "No depth variation outside promo weeks."),
 ("A15", "Promotions (effect)", "Log uplift ~ Normal(0.03 + 0.20 x depth, 0.035): modest, variable, occasionally ~0 or negative.", "Not every promotion lifts demand.", "Design choice", SYN, "Per-week draw.", "Promo effect may be ambiguous.", "Not calibrated to real data."),
 ("A16", "Event periods (Event_Flag)", "Event_Flag=1 in ISO weeks 38\u201346 (mid-Sep to mid-Nov) each year: post-monsoon / dengue-awareness seasonal illness window. Ramadan/Eid and similar periods deliberately NOT flagged.", "Plausible seasonal health pressure in Pakistan; no verified Surbex-Z link.", "Design choice", CTX + " (seasonal health context) / synthetic assignment",
  "Calendar rule via ISO week number.", "Seasonality coincides with Event_Flag windows.", "No event weeks in the holdout."),
 ("A17", "Event effect", "Per-year effect ~ Normal(0.12, 0.05) in log terms (~10\u201325% typical) plus weekly Normal(0, 0.04); realised effect not forced.", "Variable uplift; some event weeks may show little change.", "Design choice", SYN, "Draws per year and week.", "Event coefficient uncertain.", "Only two event seasons in the sample."),
 ("A18", "Marketing expenditure", "Median ~PKR 1.9m/week (~PKR 100m/yr), log-AR(1) phi 0.55, 4% annual drift, +12% (log 0.12) in promo weeks, +7% in event weeks, random 1\u20132 week bursts (+35%), rounded to PKR 10,000.", "Illustrative scale; varies enough for regression but not tied mechanically to promo, event or time.", "Design choice", SYN, "Vectorised log-AR(1).", "Moderate correlation with Promo_Flag/Event_Flag possible.", "Not Abbott's actual budget."),
 ("A19", "Marketing effect", "Weak log-elasticity of demand to marketing spend of 0.03.", "Mature brand; effect small and may be undetectable.", "Design choice", SYN, "MKT_ELAS = 0.03.", "Coefficient may be insignificant or unstable.", "Not forced positive/significant."),
 ("A20", "Stockouts", "Episodes start with probability 0.03/week (1 week 70%, 2 weeks 30%, min. 2-week gap) plus the batch-release interruption week. Observed demand = latent x fill ratio ~ Beta(6,3); week after an episode gets a rebound ~ N(0.04, 0.03) in log terms.", "Infrequent but real supply chain complication; variable suppression.", "Design choice", SYN, "Sequential loop; seeded draws.", "Stockout weeks may mislead naive forecasts.", "No fixed multiplier; severity varies."),
 ("A21", "Stockouts (interpretation)", "Actual_Demand is observed fulfilled demand; lost sales are unknown and not provided.", "Mirrors real censoring.", "Prompt requirement", SYN, "Latent series not stored.", "Forecasts built on observed data inherit censoring.", "Cannot compute lost sales."),
 ("A22", "Exceptional events", "Three one-off events fixed in advance: (1) Distribution disruption 02-Sep-2024 (2 wks); (2) Batch-release supply interruption 10-Feb-2025 (1 wk; forces Stockout_Flag=1); (3) Public-health advisory demand surge 09-Feb-2026 (2 wks). None in the holdout; none overlap Event_Flag by design.", "Plausible, distinct from seasonal events; not created for charts.", "Design choice", SYN, "Fixed dates; effect draws.", "Outliers are traceable.", "Not real Abbott incidents; real-world events of similar timing are coincidental."),
 ("A23", "Exceptional events (overlap)", "Event (2) overlaps Stockout_Flag by construction; overlaps with random stockouts/promos are recorded in Event_Log.", "Transparency.", "Event_Log", SYN, "Computed after generation.", "Effects cannot be separated cleanly.", "See Event_Log notes."),
 ("A24", "Historical forecast", "4-week trailing mean of PRIOR observed demand; week 1 = assumed prior planning figure 52,000; weeks 2\u20134 expanding mean; round half up; not recursive on forecasts; no stockout/exception adjustment; same one-step-ahead rule in holdout.", "Simple, defensible, sequentially generated benchmark; fixed before the series was generated.", "Design choice", SYN, "make_forecast() in script; recomputed by formula in Data_Audit helper table.", "Benchmark for later comparison.", "Not Abbott's actual method; one-step-ahead not 12-week."),
 ("A25", "Historical forecast (leakage control)", "Forecast for week t uses only Actual_Demand of weeks < t. Verified by Excel recomputation and a Python perturbation test (modify actual[t:] -> forecast[:t+1] unchanged, 120/120 passes).", "Critical integrity requirement.", "Data_Audit", SYN, "See audit tests.", "None.", "None."),
 ("A26", "Train/holdout split", "Weeks 1\u2013108 (11-Mar-2024 to 30-Mar-2026) = Train; weeks 109\u2013120 (06-Apr-2026 to 22-Jun-2026) = Holdout; assigned by position/date only.", "Prompt requirement.", "Prompt", SYN, "Data_Split column.", "Out-of-sample evaluation only on holdout.", "Holdout has no event weeks and a single price regime."),
 ("A27", "Reproducibility", "Random seed 353 (numpy default_rng / PCG64). Series generated ONCE; no regeneration or adjustment after seeing results.", "Reproducibility and anti-tuning.", "Script generate_surbex_dataset.py", SYN, "Single run.", "None.", "None."),
 ("A28", "Grouping rules", "Marketing groups: Low if spend <= training median (weeks 1\u2013108), High otherwise (ties -> Low). Price comparisons use Price_Regime_ID. Event/promo/stockout comparisons use the binary flags.", "Rules fixed before examining demand differences.", "Prompt Section 17", SYN, "Summary_Stats!B5 and Marketing_Group column.", "Comparisons are descriptive associations.", "Group sizes reported; small groups flagged."),
 ("A29", "Plausible ranges", "Pre-registered ranges: demand 20,000\u2013100,000; price 300\u2013700; marketing 0.3m\u201310m; promo depth <= 0.20.", "Used by audit test T17.", "Design choice", SYN, "Parameter register.", "None.", "None."),
 ("A30", "Rounding", "Demand rounded to nearest whole pack (half-even); forecast round-half-up; marketing to nearest PKR 10,000.", "Whole packs; Excel-compatible forecast recomputation.", "Design choice", SYN, "Script.", "None.", "None."),
 ("A31", "Regression specification", "Descriptive spec only: Actual_Demand = b0 + b1 Price + b2 Promo_Flag + b3 Event_Flag + b4 Marketing_Spend + e. Promo_Depth excluded from the 4-predictor block. Not a generation formula; coefficients not pre-set.", "Prompt Section 16.", "Prompt", SYN, "Regression_Readiness sheet.", "Interpret as associations.", "Confounding likely (price vs time; event vs seasonality)."),
]
for i, rowv in enumerate(A):
    for j, v in enumerate(rowv): put(AL, f"{chr(65 + j)}{5 + i}", v, border=True)
AL_FIRST, AL_LAST = 5, 5 + len(A) - 1
r = AL_LAST + 3
put(AL, f"A{r}", "Parameter register (inputs referenced by audit formulas)", f_bold, fill_sec); r += 1
header_row(AL, r, ["Parameter", "Value", "Unit", "Notes"]); r += 1
P = {}
params = [
 ("seed", SEED, "n/a", "Random seed (numpy default_rng)"), ("n_obs", N, "weeks", "Total weeks"), ("n_train", N_TRAIN, "weeks", "Training weeks (positional)"),
 ("fc_window", FC_WINDOW, "weeks", "Trailing-mean look-back"), ("fc_init", FC_INIT, "packs", "Assumed prior planning figure for week-1 forecast"),
 ("dem_lo", BOUNDS["dem"][0], "packs", "Plausibility lower bound"), ("dem_hi", BOUNDS["dem"][1], "packs", "Plausibility upper bound"),
 ("price_lo", BOUNDS["price"][0], "PKR", "Plausibility lower bound"), ("price_hi", BOUNDS["price"][1], "PKR", "Plausibility upper bound"),
 ("mkt_lo", BOUNDS["mkt"][0], "PKR", "Plausibility lower bound"), ("mkt_hi", BOUNDS["mkt"][1], "PKR", "Plausibility upper bound"),
 ("depth_max", BOUNDS["depth_max"], "proportion", "Max plausible promo depth"),
 ("corr_thr", CORR_THR, "|r|", "Warning threshold for predictor correlation"), ("vif_thr", VIF_THR, "VIF", "Warning threshold for VIF"),
 ("small_n", SMALL_N, "weeks", "Group size below which a descriptive group is flagged"),
 ("price_distinct_min", 10, "values", "Fewer distinct training prices than this -> limited price variation warning"),
]
for nm, v, u, nt in params:
    put(AL, f"A{r}", nm, border=True); put(AL, f"B{r}", v, f_in, border=True); put(AL, f"C{r}", u, border=True); put(AL, f"D{r}", nt, border=True)
    P[nm] = f"Assumption_Log!$B${r}"; r += 1
r += 1
put(AL, f"A{r}", "Price regime definitions (inputs; illustrative \u2014 NOT actual Abbott prices or DRAP approvals)", f_bold, fill_sec); r += 1
header_row(AL, r, ["Regime_ID", "Start_Date", "End_Date", "Price_PKR_per_30s_pack", "Assumption_behind_transition"]); r += 1
REG_FIRST = r
trans = ["Initial regime at start of series (previous price history unknown).", "Assumed annual-ish adjustment (+9.1%) after the Feb-2024 deregulation of non-essential drug prices.",
         "Assumed CPI-linked annual adjustment (+9.0%).", "Assumed CPI-linked annual adjustment (+7.0%) as inflation eased."]
for k, (rid, s, p_) in enumerate(PRICE_REGIMES):
    end = (pd.Timestamp(PRICE_REGIMES[k + 1][1]) - pd.Timedelta(days=7)) if k < 3 else dates[-1]
    put(AL, f"A{r}", rid, f_in, border=True)
    c = put(AL, f"B{r}", pd.Timestamp(s).to_pydatetime(), f_in, fmt="dd-mmm-yyyy", border=True)
    put(AL, f"C{r}", end.to_pydatetime(), f_in, fmt="dd-mmm-yyyy", border=True)
    put(AL, f"D{r}", p_, f_in, fmt="#,##0", border=True); put(AL, f"E{r}", trans[k], border=True); r += 1
REG_LAST = r - 1
REG_IDS = f"Assumption_Log!$A${REG_FIRST}:$A${REG_LAST}"; REG_STARTS = f"Assumption_Log!$B${REG_FIRST}:$B${REG_LAST}"
REG_PRICES = f"Assumption_Log!$D${REG_FIRST}:$D${REG_LAST}"
widths(AL, dict(A=14, B=26, C=52, D=40, E=26, F=26, G=34, H=34, I=40))

# ----------------------------------------------------------------------------------
# README
# ----------------------------------------------------------------------------------
put(RM, "A1", "MGT-353 Supply Chain Analytics \u2014 Surbex-Z 30s Weekly Demand: Company-Calibrated Synthetic Dataset", f_title, wrap=False)
rows = [
 ("Course", "MGT-353 Supply Chain Analytics, IBA Karachi (applied company project)."),
 ("Company and product", "Abbott Laboratories (Pakistan) Limited (PSX: ABOT), pharmaceuticals & healthcare. Product: Surbex-Z 30s (pack of 30 tablets). Market: Pakistan. Frequency: weekly."),
 ("Core business decision", "How many Surbex-Z 30s packs should Abbott plan to supply over the next 12 weeks, and how much should it commit now versus keep flexible? (Primary decision-maker: Head of Supply Chain; other users: Sales & Marketing, Operations/Production, Procurement, Finance.)"),
 ("MANDATORY LABEL", LABEL),
 ("Explicit statement", "ALL product-level values in this workbook (demand, forecasts, prices, promotions, marketing spend, events, stockouts) are SYNTHETIC. They are NOT Abbott records, were NOT provided by Abbott, and must not be cited as actual Surbex-Z sales, prices or spending. Company-level public figures are used only as context for scale."),
 ("Purpose", "A frozen, auditable data foundation for later forecasting, uncertainty analysis, descriptive regression, dashboard and supply-planning recommendation. This workbook does NOT choose a forecasting model or make the supply recommendation."),
 ("Observations", f'=COUNT({rg("A")})&" weekly observations (one per Monday)"'),
 ("Date range", f'=TEXT(MIN({rg("A")}),"dd mmm yyyy")&" to "&TEXT(MAX({rg("A")}),"dd mmm yyyy")'),
 ("Training / holdout", f'="Train: "&COUNTIF({rg("L")},"Train")&" weeks, "&TEXT(MINIFS_PLACEHOLDER,"dd mmm yyyy")'),
 ("Units", "Demand/forecast: packs (30-tablet). Price: PKR per pack (illustrative printed MRP). Marketing_Spend: PKR per week. Promo_Depth: decimal proportion (0.10 = 10%). Flags: 0/1."),
 ("How the data were generated (order actually used)",
  "1 weekly Monday dates; 2 train/holdout by position; 3 baseline + trend + background seasonality; 4 price regimes; 5 promotions & depth; 6 recurring seasonal Event_Flag; 7 marketing spend; "
  "8 exceptional events; 9 latent demand with AR(1) fat-tailed noise; 10 stockout mechanism -> observed demand; 11 leakage-free 4-week trailing-mean historical forecast; 12 quality-control checks; 13 summaries and audit. "
  "Parameters were fixed before generation; the series was generated once (seed 353) and never regenerated or tuned."),
 ("Stockout limitation", "Actual_Demand is observed synthetic sales/fulfilled packs. In Stockout_Flag=1 weeks it is suppressed by a random fill ratio, so it understates unconstrained customer demand. Lost sales are unknown and cannot be recovered from this dataset."),
 ("Reproducibility", "Random seed = 353 (numpy default_rng). Script: generate_surbex_dataset.py. No individual observation was manually edited."),
 ("Key limitations", "Synthetic data; price is a step function that rises with time (price\u2013trend confounding); few price regimes; only two seasonal event seasons; holdout has no event weeks and one price regime; "
  "realised promotion rate and stockout count are whatever the single seeded run produced (promotion rate is above the 15\u201320% starting range; stockouts are few, so stockout comparisons rest on very small groups); forecast benchmark is one-step-ahead; FY2025 company net sales not verified at original source; regression/group comparisons are associations, not causal effects."),
 ("Workbook version", "v1.0"),
 ("Freeze status", f"={AUDIT_OVERALL}"),
 ("Freeze status meaning", "READY TO FREEZE = all critical integrity checks passed and warnings are documented; it does NOT mean the workbook has been formally frozen. Status becomes FROZEN only after explicit approval."),
 ("Sheet guide", "README | Synthetic_Data (raw table; banner row 1, header row 2, data rows 3\u2013122) | Data_Dictionary | Assumption_Log | Data_Audit | Summary_Stats | Event_Log | Forecast_Setup | Regression_Readiness."),
 ("Colour legend", "Blue font = hard-coded input/assumption. Black = formula/text. Yellow banner = mandatory label. Amber = WARNING; green = PASS; red = FAIL."),
]
rr = 3; RMAP = {}
for lab, txt in rows:
    if lab == "Training / holdout":
        txt = (f'="Train: "&COUNTIF({rg("L")},"Train")&" weeks ("&TEXT(_xlfn.MINIFS({rg("A")},{rg("L")},"Train"),"dd mmm yyyy")&" to "&TEXT(_xlfn.MAXIFS({rg("A")},{rg("L")},"Train"),"dd mmm yyyy")&"); Holdout: "'
               f'&COUNTIF({rg("L")},"Holdout")&" weeks ("&TEXT(_xlfn.MINIFS({rg("A")},{rg("L")},"Holdout"),"dd mmm yyyy")&" to "&TEXT(_xlfn.MAXIFS({rg("A")},{rg("L")},"Holdout"),"dd mmm yyyy")&")"')
    put(RM, f"A{rr}", lab, f_bold, fill_sec, border=True)
    fnt = Font(name=FN, size=11, bold=True, color="7F6000") if lab == "MANDATORY LABEL" else f_norm
    put(RM, f"B{rr}", txt, fnt, fill_lab if lab == "MANDATORY LABEL" else None, border=True)
    RMAP[lab] = rr; rr += 1
LABEL_CELL = f"README!$B${RMAP['MANDATORY LABEL']}"
VERSION_CELL = f"README!$B${RMAP['Workbook version']}"; FREEZE_CELL = f"README!$B${RMAP['Freeze status']}"
rr += 1
put(RM, f"A{rr}", "Public calibration sources (used for context only)", f_bold, fill_sec, wrap=False); rr += 1
src_head = ["Source_ID", "Exact_Document_Title", "Publisher", "Publication_Year_or_Date", "Page_or_Section", "Direct_URL",
            "Exact_Figure_or_Statement_Used", "Units_and_Reporting_Period", "How_It_Informs_The_Dataset", "Independently_Verified_From_Original"]
header_row(RM, rr, src_head); rr += 1
SRC_FIRST = rr
SRC = [
 ("S1", "Abbott Pakistan \u2014 2025 Annual Report (Abbott Laboratories (Pakistan) Limited)", "Abbott Laboratories (Pakistan) Limited; document hosted on PSX Data Portal",
  "2026 (signed 25 Mar 2026; transmitted to PSX 8 Apr 2026)", "p.7 Ownership; p.18 Key Brands; p.31 SWOT; p.34 Key Risks; p.54 shareholding statement; p.60 Chairman's review (printed page numbers)",
  "https://dps.psx.com.pk/download/document/273772.pdf",
  "Surbex Z described as no.1 brand by value, volume and prescriptions in the Vitamin B complex market (IQVIA MAT Dec 2025), 21.4m annual prescriptions, 29-year history; directors' shareholdings stated as at 31 Dec 2025; 'regulated prices' listed as a weakness; Chairman welcomes changes for non-essential drugs outside the NEML.",
  "Qualitative; calendar year 2025 / MAT Dec 2025", "Supports an established-brand scenario, the 31-Dec fiscal year-end and the regulated-price context. No product volumes or prices disclosed. Pages 62+ (Directors' report, financial statements) were NOT read: retrieval truncated.", "Yes (text read from the PDF)"),
 ("S2", "Abbott Laboratories (Pakistan) Limited \u2014 PSX company page, Financial Results listing", "Pakistan Stock Exchange (PSX Data Portal)", "2026 (lists filings of 16 Mar 2026 and 8 Apr 2026)", "Company page > Financial Results",
  "https://dps.psx.com.pk/company/ABOT",
  "Lists 'Financial Results for the Year Ended December 31, 2025' (filed 16 Mar 2026) and annual report for the year ended 31 Dec 2025; annual profit after tax shown as 7,966,500 (Rs 000).",
  "PKR thousand; FY ended 31 Dec 2025", "Confirms fiscal year-end of 31 December.", "Yes for fiscal year-end (listing read); results PDF itself not opened"),
 ("S3", "Financial Highlights 2024 (Abbott Pakistan 2024 Annual Report)", "Abbott Laboratories (Pakistan) Limited", "2025 (FY2024 report)", "Key Operating and Financial Highlights (p.73 of the 2024 report)",
  "https://www.pk.abbott/content/dam/corp/abbott/en-pk/documents/pdfs/investor/Financial-Highlights-2024.pdf",
  "Net sales 2024 = 68,177; 2023 = 55,475 (Rupees in million).", "PKR million; FY ended 31 Dec 2024", "Official prior-year base used only to sanity-check the reported FY2025 growth; context for company scale.", "Yes (official document text seen via search extract)"),
 ("S4", "ABOT posts 52% profit jump, Rs40/share dividend (MG News / Mettis Global)", "Mettis Global (MLN)", "16 Mar 2026", "Article body, results table",
  "https://mettisglobal.news/ABOT-posts-52-profit-jump-Rs40share-dividend-59061",
  "Reports FY2025 net sales of Rs75.40bn, up 10.6% from Rs68.18bn; net profit Rs7.97bn.", "PKR billion; FY ended 31 Dec 2025", "Company-level scale context ONLY (not product revenue).", "No \u2014 secondary report; original results filing not opened"),
 ("S5", "PSX:ABOT Revenue (StockAnalysis.com)", "StockAnalysis.com (aggregator)", "Undated page; accessed 9 Oct 2026", "Revenue History table",
  "https://stockanalysis.com/quote/psx/ABOT/revenue/", "Annual revenue for year ended 31 Dec 2025 shown as PKR 75.40B (+10.59%).", "PKR billion; FY ended 31 Dec 2025", "Corroborates S4 only; context.", "No \u2014 aggregator"),
 ("S6", "S.R.O. 595(I)/2023 \u2014 Notification: one-time CPI-based dispensation for maximum retail prices (19 May 2023)", "Government of Pakistan / Drug Regulatory Authority of Pakistan", "19 May 2023", "Notification text",
  "https://www.dra.gov.pk/wp-content/uploads/2023/05/CPI-Increase-Notification-19.05.2023.pdf",
  "MRPs of drugs are fixed by the Federal Government under the DRAP Act (s.7(a)) read with s.12 Drugs Act; one-time increase up to CPI with caps of 14% (essential) and 20% (others); revised MRPs to be printed on labels.", "Regulatory text; FY2023-24",
  "Establishes that retail prices are regulated MRPs changed through formal adjustments, supporting long stable synthetic price regimes.", "Yes (official notification text seen via search extract)"),
 ("S7", "Govt approves deregulation of medicine prices outside NEML (Profit)", "Pakistan Today (Profit)", "7 Feb 2024", "Article body",
  "https://profit.pakistantoday.com.pk/2024/02/07/govt-approves-deregulation-of-medicine-prices-outside-neml",
  "Describes 2018 Drug Pricing Policy (CPI-linked, 30 days' notice, non-essential increases up to CPI with 10% maximum) and approval of deregulation of non-essential drug prices.", "Policy description; 2018\u20132024",
  "Context for annual-ish, <=~10% price steps assumed in the synthetic regimes.", "No \u2014 secondary; original notification not opened"),
 ("S8", "55pc drugs' prices went up after deregulation in 2024: DRAP (The News)", "The News International", "Year not explicitly captured (content refers to 2025/2026 pricing surveys)", "Article body",
  "https://www.thenews.pk/print/1414399-55pc-drugs-prices-went-up-after-deregulation-in-2024-drap",
  "Refers to deregulation under SRO 228(I)/2024; DRAP survey of 771 SKUs found most prices rose, roughly 43% below prior MRP, ~2% unchanged.", "Survey of top non-essential brands",
  "Context that post-deregulation price changes occur at firm level.", "No \u2014 secondary"),
 ("S9", "Deregulation of non-essential drugs on the cards (Business Recorder)", "Business Recorder", "Print edition 16 Feb 2024", "Article body",
  "https://www.brecorder.com/news/amp/40289136",
  "Reports cabinet proposals incl. exempting non-essential drugs from MRP fixing and asking the medical council to prohibit prescribing of vitamins/multivitamins/OTC products.", "Policy proposals; Feb 2024",
  "Regulatory-risk context for the vitamin category; NOT applied in the generated data.", "No \u2014 secondary"),
]
for i, s in enumerate(SRC):
    for j, v in enumerate(s): put(RM, f"{chr(65 + j)}{rr}", v, border=True)
    rr += 1
SRC_LAST = rr - 1
rr += 1
put(RM, f"A{rr}", "Source-verification summary", f_bold, fill_sec); 
put(RM, f"B{rr}", "Fiscal year-end (31 Dec): verified from primary PSX/company documents (S1, S2). FY2025 company net sales (PKR 75.40bn): reported consistently by two secondary sources (S4, S5) and consistent with the official FY2024 base (S3: Rs68.18bn) and the PSX-listed FY2025 profit; "
    "however, the net-sales line in the original filing/annual report could not be opened, so it is NOT independently verified at source. It is used for context only and never as Surbex-Z revenue.", border=True)
REV_VER_CELL = f"README!$J${SRC_FIRST + 3}"   # S4 row = the FY2025 revenue source
widths(RM, dict(A=28, B=70, C=30, D=24, E=34, F=42, G=60, H=26, I=46, J=26))

# ----------------------------------------------------------------------------------
# Summary_Stats
# ----------------------------------------------------------------------------------
put(SS, "A1", "Summary Statistics (formula-linked to Synthetic_Data)", f_title, wrap=False)
put(SS, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
put(SS, "A3", "Scope labels: ALL = weeks 1\u2013120; TRAIN = weeks 1\u2013108; HOLDOUT = weeks 109\u2013120 (descriptive only; not used for any design decision). Group comparisons are descriptive ASSOCIATIONS, not causal effects.", f_ital, wrap=False)
put(SS, "A5", "Marketing-group threshold = median Marketing_Spend, TRAINING weeks only (PKR); Low if <= threshold (ties -> Low), High if >", f_bold, wrap=True)
put(SS, "B5", f'=MEDIAN({rg("I", *TR)})', f_bold, fmt="#,##0")
SS.row_dimensions[5].height = 42
row = 7
put(SS, f"A{row}", "1. Demand statistics (Actual_Demand, packs)", f_bold, fill_sec); row += 1
header_row(SS, row, ["Statistic", "ALL (120)", "TRAIN (108)", "HOLDOUT (12, descriptive only)", "Note"]); row += 1
S = {}
def rowstat(label, fa, ft, fh, note="", fmt="#,##0.00", key=None):
    global row
    put(SS, f"A{row}", label, border=True)
    for col, f in zip("BCD", (fa, ft, fh)):
        put(SS, f"{col}{row}", f, fmt=fmt, border=True)
    put(SS, f"E{row}", note, f_ital, border=True)
    if key: S[key] = row
    row += 1
def over(fn, col):
    return [f"={fn}({rg(col, *sc)})" for sc in (ALL, TR, HO)]
a_ = over("COUNT", "C"); rowstat("Observation count", *a_, fmt="0", key="n")
a_ = over("AVERAGE", "C"); rowstat("Mean demand", *a_, key="mean")
a_ = over("MEDIAN", "C"); rowstat("Median demand", *a_, key="med")
a_ = over("STDEV", "C"); rowstat("Std deviation (sample)", *a_, key="sd")
a_ = over("MIN", "C"); rowstat("Minimum demand", *a_, fmt="#,##0", key="min")
a_ = over("MAX", "C"); rowstat("Maximum demand", *a_, fmt="#,##0", key="max")
rowstat("Demand range (max-min)", *[f"={c}{S['max']}-{c}{S['min']}" for c in "BCD"], fmt="#,##0", key="rng")
rowstat("Coefficient of variation (sd/mean)", *[f"={c}{S['sd']}/{c}{S['mean']}" for c in "BCD"], fmt="0.0%", key="cv")
rowstat("Mean demand \u2014 first 52 weeks", f'=AVERAGE({rg("C", 3, 54)})', f'=AVERAGE({rg("C", 3, 54)})', "n/a", "Weeks 1\u201352", key="first")
rowstat("Mean demand \u2014 last 52 weeks", f'=AVERAGE({rg("C", 71, 122)})', f'=AVERAGE({rg("C", 59, 110)})', "n/a", "ALL: weeks 69\u2013120; TRAIN: weeks 57\u2013108", key="last")
row += 1
put(SS, f"A{row}", "2. Frequencies and rates", f_bold, fill_sec); row += 1
header_row(SS, row, ["Statistic", "ALL (120)", "TRAIN (108)", "HOLDOUT (12, descriptive only)", "Note"]); row += 1
a_ = over("SUM", "F"); rowstat("Promotional weeks (count)", *a_, fmt="0", key="pc")
rowstat("Promotion rate", *[f"={c}{S['pc']}/{c}{S['n']}" for c in "BCD"], fmt="0.0%", key="pr")
a_ = over("SUM", "H"); rowstat("Event weeks (count)", *a_, fmt="0", key="ec")
rowstat("Event rate", *[f"={c}{S['ec']}/{c}{S['n']}" for c in "BCD"], fmt="0.0%", key="er")
a_ = over("SUM", "J"); rowstat("Stockout weeks (count)", *a_, fmt="0", key="sc")
rowstat("Stockout rate", *[f"={c}{S['sc']}/{c}{S['n']}" for c in "BCD"], fmt="0.0%", key="sr")
a_ = [f'=COUNTIF({rg("K", *sc)},"<>None")' for sc in (ALL, TR, HO)]; rowstat("Exceptional-event weeks (count)", *a_, fmt="0", key="xw")
def distinct_exc(a, b):
    return (f'=--(Synthetic_Data!$K${a}<>"None")+SUMPRODUCT((Synthetic_Data!$K${a + 1}:$K${b}<>"None")*(Synthetic_Data!$K${a + 1}:$K${b}<>Synthetic_Data!$K${a}:$K${b - 1}))')
rowstat("Exceptional events (distinct episodes)", *[distinct_exc(*sc) for sc in (ALL, TR, HO)], fmt="0", key="xe")
rowstat("Price regimes present (count)", *[f"=MAX({rg('N', *sc)})-MIN({rg('N', *sc)})+1" for sc in (ALL, TR, HO)], fmt="0", key="nreg")
row += 1
put(SS, f"A{row}", "3. Marketing_Spend statistics (PKR per week)", f_bold, fill_sec); row += 1
header_row(SS, row, ["Statistic", "ALL (120)", "TRAIN (108)", "HOLDOUT (12, descriptive only)", "Note"]); row += 1
for lab, fn in [("Minimum", "MIN"), ("Maximum", "MAX"), ("Mean", "AVERAGE"), ("Median", "MEDIAN"), ("Std deviation (sample)", "STDEV")]:
    a_ = over(fn, "I"); rowstat(lab, *a_, fmt="#,##0", key="m_" + fn)
row += 1
put(SS, f"A{row}", "4. Price regimes (descriptive association with demand; TRAIN weeks only for demand means)", f_bold, fill_sec); row += 1
header_row(SS, row, ["Regime_ID", "Start (first week)", "End (last week)", "Duration (weeks, all)", "Price (PKR)", "n (TRAIN weeks)", "Mean Actual_Demand (TRAIN)", "Small-group flag"]); row += 1
RG_FIRST = row
for k in range(4):
    rid = k + 1
    put(SS, f"A{row}", rid, border=True, fmt="0")
    put(SS, f"B{row}", f'=_xlfn.MINIFS({rg("A")},{rg("N")},A{row})', fmt="dd-mmm-yyyy", border=True)
    put(SS, f"C{row}", f'=_xlfn.MAXIFS({rg("A")},{rg("N")},A{row})', fmt="dd-mmm-yyyy", border=True)
    put(SS, f"D{row}", f'=COUNTIF({rg("N")},A{row})', fmt="0", border=True)
    put(SS, f"E{row}", f'=AVERAGEIFS({rg("E")},{rg("N")},A{row})', fmt="#,##0", border=True)
    put(SS, f"F{row}", f'=COUNTIFS({rg("N")},A{row},{rg("L")},"Train")', fmt="0", border=True)
    put(SS, f"G{row}", f'=AVERAGEIFS({rg("C")},{rg("N")},A{row},{rg("L")},"Train")', fmt="#,##0", border=True)
    put(SS, f"H{row}", f'=IF(F{row}<{P["small_n"]},"SMALL GROUP","")', border=True)
    row += 1
RG_LAST = row - 1
row += 1
put(SS, f"A{row}", "5. Predefined descriptive group comparisons (associations, NOT causal effects)", f_bold, fill_sec); row += 1
header_row(SS, row, ["Comparison", "Group", "Scope", "n (weeks)", "Mean Actual_Demand", "Mean diff vs reference group", "Small-group flag"]); row += 1
CMP_FIRST = row
def cmp_rows(title, g1lab, g2lab, crit_col, v1, v2, scope):
    global row
    cond = "" if scope == "ALL" else f',{rg("L")},"Train"'
    for lab, v, ref in ((g1lab, v1, None), (g2lab, v2, "ref")):
        put(SS, f"A{row}", title, border=True); put(SS, f"B{row}", lab, border=True); put(SS, f"C{row}", scope, border=True)
        crit = v if isinstance(v, str) else v
        put(SS, f"D{row}", f'=COUNTIFS({rg(crit_col)},{crit}{cond})', fmt="0", border=True)
        put(SS, f"E{row}", f'=AVERAGEIFS({rg("C")},{rg(crit_col)},{crit}{cond})', fmt="#,##0", border=True)
        put(SS, f"G{row}", f'=IF(D{row}<{P["small_n"]},"SMALL GROUP (n<"&{P["small_n"]}&")","")', border=True)
        if ref: put(SS, f"F{row}", f"=E{row - 1}-E{row}", fmt="#,##0;-#,##0", border=True)
        else: put(SS, f"F{row}", "(first group \u2212 second group on next row)", f_ital, border=True)
        row += 1
for sc in ("ALL", "TRAIN"):
    cmp_rows("Promo_Flag", "Promo=1", "Promo=0", "F", "1", "0", sc)
    cmp_rows("Event_Flag", "Event=1", "Event=0", "H", "1", "0", sc)
    cmp_rows("Stockout_Flag", "Stockout=1", "Stockout=0", "J", "1", "0", sc)
for sc in ("ALL", "TRAIN"):
    cmp_rows("Marketing_Group (training-median rule)", "High (> threshold)", "Low (<= threshold)", "O", '"High"', '"Low"', sc)
CMP_LAST = row - 1
row += 1
put(SS, f"A{row}", "6. Python cross-check of key statistics (static reference values computed independently at build time)", f_bold, fill_sec); row += 1
header_row(SS, row, ["Metric", "Workbook formula", "Python reference", "Absolute difference"]); row += 1
XC_FIRST = row
a_all, a_tr = df.Actual_Demand.to_numpy(), df.Actual_Demand.to_numpy()[:N_TRAIN]
xc = [("Mean demand (ALL)", f"=B{S['mean']}", a_all.mean()), ("Median demand (ALL)", f"=B{S['med']}", float(np.median(a_all))),
      ("Std dev demand (ALL)", f"=B{S['sd']}", a_all.std(ddof=1)), ("Min demand (ALL)", f"=B{S['min']}", float(a_all.min())),
      ("Max demand (ALL)", f"=B{S['max']}", float(a_all.max())), ("Mean demand (TRAIN)", f"=C{S['mean']}", a_tr.mean()),
      ("Std dev demand (TRAIN)", f"=C{S['sd']}", a_tr.std(ddof=1)), ("Promotion rate (ALL)", f"=B{S['pr']}", df.Promo_Flag.mean()),
      ("Marketing-group threshold (TRAIN median)", "=B5", float(np.median(df.Marketing_Spend.to_numpy()[:N_TRAIN])))]
for lab, f, pv in xc:
    put(SS, f"A{row}", lab, border=True); put(SS, f"B{row}", f, fmt="#,##0.0000", border=True)
    put(SS, f"C{row}", float(pv), f_in, fmt="#,##0.0000", border=True); put(SS, f"D{row}", f"=ABS(B{row}-C{row})", fmt="0.000000", border=True); row += 1
XC_LAST = row - 1
widths(SS, dict(A=44, B=22, C=20, D=26, E=28, F=28, G=30, H=18))

# ----------------------------------------------------------------------------------
# Regression_Readiness
# ----------------------------------------------------------------------------------
put(RR, "A1", "Regression Readiness", f_title, wrap=False)
put(RR, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
put(RR, "A4", "Proposed DESCRIPTIVE specification (analytical, not a generation formula):", f_bold, wrap=False)
put(RR, "A5", "Actual_Demand = \u03b20 + \u03b21(Price) + \u03b22(Promo_Flag) + \u03b23(Event_Flag) + \u03b24(Marketing_Spend) + \u03b5", f_bold, wrap=False)
put(RR, "A6", "Fit on TRAIN weeks only (rows 3\u2013110). Coefficients are associations; the price coefficient is NOT a causal elasticity. No coefficients are reported here by design.", f_ital, wrap=False)
rr_ = 8
put(RR, f"A{rr_}", "A. Predictor definitions", f_bold, fill_sec); rr_ += 1
header_row(RR, rr_, ["Predictor", "Definition", "Unit"]); rr_ += 1
for a, b, c in [("Price", "Illustrative printed MRP per 30-tablet pack", "PKR"), ("Promo_Flag", "1 = promotional week", "0/1"),
                ("Event_Flag", "1 = recurring seasonal health-pressure window (ISO weeks 38\u201346)", "0/1"), ("Marketing_Spend", "Weekly illustrative marketing spend", "PKR")]:
    put(RR, f"A{rr_}", a, border=True); put(RR, f"B{rr_}", b, border=True); put(RR, f"C{rr_}", c, border=True); rr_ += 1
rr_ += 1
vars_ = [("Actual_Demand", "C"), ("Historical_Forecast", "D"), ("Price", "E"), ("Promo_Flag", "F"), ("Promo_Depth", "G"),
         ("Event_Flag", "H"), ("Marketing_Spend", "I"), ("Stockout_Flag", "J")]
CORR = {}
for title, sc, key in (("B. Correlation matrix \u2014 TRAIN weeks only (weeks 1\u2013108; primary for modelling)", TR, "tr"),
                       ("C. Correlation matrix \u2014 ALL 120 weeks (descriptive; includes holdout)", ALL, "all")):
    put(RR, f"A{rr_}", title, f_bold, fill_sec); rr_ += 1
    header_row(RR, rr_, ["Variable"] + [v for v, _ in vars_]); top = rr_; rr_ += 1
    CORR[key] = {}
    for i, (vn, vc) in enumerate(vars_):
        put(RR, f"A{rr_}", vn, f_bold, border=True)
        for j, (wn, wc) in enumerate(vars_):
            colL = chr(66 + j)
            put(RR, f"{colL}{rr_}", f"=CORREL({rg(vc, *sc)},{rg(wc, *sc)})", fmt="0.000", border=True)
            CORR[key][(vn, wn)] = f"{colL}{rr_}"
        rr_ += 1
    rr_ += 1
put(RR, f"A{rr_}", "D. Predictor variation checks (4 specified predictors + Promo_Depth)", f_bold, fill_sec); rr_ += 1
header_row(RR, rr_, ["Predictor", "Scope", "Min", "Max", "Std dev", "Distinct values", "Missing (blank cells)", "Variation OK?"]); rr_ += 1
VAR_FIRST = rr_
for vn, vc in [("Price", "E"), ("Promo_Flag", "F"), ("Promo_Depth", "G"), ("Event_Flag", "H"), ("Marketing_Spend", "I")]:
    for scn, sc in (("TRAIN", TR), ("HOLDOUT", HO)):
        rgx = rg(vc, *sc)
        put(RR, f"A{rr_}", vn, border=True); put(RR, f"B{rr_}", scn, border=True)
        put(RR, f"C{rr_}", f"=MIN({rgx})", fmt="#,##0.###", border=True); put(RR, f"D{rr_}", f"=MAX({rgx})", fmt="#,##0.###", border=True)
        put(RR, f"E{rr_}", f"=STDEV({rgx})", fmt="#,##0.###", border=True)
        put(RR, f"F{rr_}", f"=SUMPRODUCT(1/COUNTIF({rgx},{rgx}))", fmt="0", border=True)
        put(RR, f"G{rr_}", f"=COUNTBLANK({rgx})", fmt="0", border=True)
        put(RR, f"H{rr_}", f'=IF(F{rr_}>1,"OK","NO VARIATION")', border=True); rr_ += 1
VAR_LAST = rr_ - 1
put(RR, f"A{rr_}", "Missing values in all 11 required columns (ALL weeks):", f_bold, border=True)
put(RR, f"B{rr_}", f"=COUNTBLANK(Synthetic_Data!$A${R0}:$K${RN})", fmt="0", border=True); MISS_CELL = f"B{rr_}"; rr_ += 2
put(RR, f"A{rr_}", "E. Multicollinearity review (TRAIN weeks; 4 specified predictors)", f_bold, fill_sec); rr_ += 1
preds = ["Price", "Promo_Flag", "Event_Flag", "Marketing_Spend"]
put(RR, f"A{rr_}", "Predictor correlation block (linked to matrix B)", f_bold, wrap=False); rr_ += 1
header_row(RR, rr_, ["Variable"] + preds); rr_ += 1
PB_FIRST = rr_
for pn in preds:
    put(RR, f"A{rr_}", pn, f_bold, border=True)
    for j, qn in enumerate(preds):
        put(RR, f"{chr(66 + j)}{rr_}", f"={CORR['tr'][(pn, qn)]}", fmt="0.000", border=True)
    rr_ += 1
PB_LAST = rr_ - 1
rr_ += 1
put(RR, f"A{rr_}", "Inverse of the predictor correlation block (MINVERSE); diagonal = VIF", f_bold, wrap=False); rr_ += 1
INV_FIRST = rr_
RR[f"B{rr_}"] = ArrayFormula(f"B{rr_}:E{rr_ + 3}", f"=MINVERSE(B{PB_FIRST}:E{PB_LAST})")
for k, pn in enumerate(preds):
    put(RR, f"A{rr_ + k}", pn, f_bold, border=True)
    for j in range(4): RR[f"{chr(66 + j)}{rr_ + k}"].number_format = "0.000"; RR[f"{chr(66 + j)}{rr_ + k}"].font = f_norm
rr_ += 5
header_row(RR, rr_, ["Predictor", "VIF", "Flag (VIF > threshold)"]); rr_ += 1
VIF_FIRST = rr_
for k, pn in enumerate(preds):
    put(RR, f"A{rr_}", pn, border=True); put(RR, f"B{rr_}", f"={chr(66 + k)}{INV_FIRST + k}", fmt="0.000", border=True)
    put(RR, f"C{rr_}", f'=IF(B{rr_}>{P["vif_thr"]},"WARNING","OK")', border=True); rr_ += 1
VIF_LAST = rr_ - 1
c = CORR["tr"]
pairs = [("Price", "Promo_Flag"), ("Price", "Event_Flag"), ("Price", "Marketing_Spend"), ("Promo_Flag", "Event_Flag"), ("Promo_Flag", "Marketing_Spend"), ("Event_Flag", "Marketing_Spend")]
put(RR, f"A{rr_}", "Max |r| among the 4 predictors (TRAIN)", f_bold, border=True)
put(RR, f"B{rr_}", "=MAX(" + ",".join(f"ABS({c[p]})" for p in pairs) + ")", fmt="0.000", border=True); MAXR_CELL = f"Regression_Readiness!$B${rr_}"; rr_ += 1
put(RR, f"A{rr_}", "Max VIF among the 4 predictors (TRAIN)", f_bold, border=True)
put(RR, f"B{rr_}", f"=MAX(B{VIF_FIRST}:B{VIF_LAST})", fmt="0.000", border=True); MAXVIF_CELL = f"Regression_Readiness!$B${rr_}"; rr_ += 1
put(RR, f"A{rr_}", "Correlation of Price with Week_Number (TRAIN) \u2014 price/time confounding indicator", f_bold, border=True)
put(RR, f"B{rr_}", f'=CORREL({rg("E", *TR)},{rg("M", *TR)})', fmt="0.000", border=True); PT_CELL = f"Regression_Readiness!$B${rr_}"; rr_ += 2
put(RR, f"A{rr_}", "F. Training vs holdout identification", f_bold, fill_sec); rr_ += 1
for lab, f in [("TRAIN rows (Synthetic_Data rows 3\u2013110)", f'=COUNTIF({rg("L")},"Train")'), ("HOLDOUT rows (Synthetic_Data rows 111\u2013122)", f'=COUNTIF({rg("L")},"Holdout")')]:
    put(RR, f"A{rr_}", lab, border=True); put(RR, f"B{rr_}", f, fmt="0", border=True); rr_ += 1
rr_ += 1
put(RR, f"A{rr_}", "G. Notes on confounding and interpretation", f_bold, fill_sec); rr_ += 1
for t_ in ["Price is a rising step function (4 regimes) and is strongly associated with Week_Number; any price coefficient is confounded with trend and is an association, not a causal elasticity.",
           "Promo_Depth is nonzero only when Promo_Flag = 1 (collinear by construction); use one of the two in a regression, not both.",
           "Event_Flag coincides with seasonal windows (mid-Sep to mid-Nov) and with seasonally higher marketing; its coefficient mixes seasonality, event pressure and marketing.",
           "Stockout weeks suppress observed demand; excluding or controlling for them is an analyst choice that should be documented (Stockout_Flag is available).",
           "Exceptional-event weeks are outliers by design; document any treatment.",
           "The holdout has a single price regime and no event weeks, so out-of-sample evaluation cannot assess those effects.",
           "Do not use the holdout to select predictors or tune the data; fit and select on TRAIN only. Do not force significance or sign."]:
    put(RR, f"A{rr_}", "\u2022 " + t_, wrap=False); rr_ += 1
widths(RR, dict(A=44, B=18, C=18, D=16, E=16, F=16, G=18, H=16, I=16))

# ----------------------------------------------------------------------------------
# Event_Log
# ----------------------------------------------------------------------------------
put(EL, "A1", "Event Log \u2014 events and structural changes", f_title, wrap=False)
put(EL, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
header_row(EL, 4, ["Date_Start", "Date_End", "Event_Name", "Event_Type", "Relevant_Variable_or_Flag", "Synthetic_or_Public_Source_Status",
                   "Description", "Assumed_Effect", "Supporting_Source_or_Assumption_Ref", "Overlap_Notes"])
ev_rows = []
def runs(mask):
    out, i = [], 0
    while i < N:
        if mask[i]:
            j = i
            while j + 1 < N and mask[j + 1]: j += 1
            out.append((i, j)); i = j + 1
        else: i += 1
    return out
def overlap_txt(i, j, skip):
    parts = []
    sl = slice(i, j + 1)
    if "promo" not in skip and promo[sl].sum(): parts.append(f"{int(promo[sl].sum())} promo wk")
    if "event" not in skip and event[sl].sum(): parts.append(f"{int(event[sl].sum())} Event_Flag wk")
    if "stock" not in skip and stock[sl].sum(): parts.append(f"{int(stock[sl].sum())} stockout wk")
    if "exc" not in skip and (exc_label[sl] != "None").sum(): parts.append(f"{int((exc_label[sl] != 'None').sum())} exceptional-event wk")
    return "Overlaps: " + ", ".join(parts) if parts else "No overlap with other flags."
for (i, j) in runs(event == 1):
    ev_rows.append((dates[i], dates[j], f"Seasonal health-pressure window {dates[i].year}", "Recurring seasonal event", "Event_Flag", "Synthetic assignment (seasonal context only)",
                    "Post-monsoon / dengue-awareness illness season, ISO weeks 38\u201346.", "Mean log uplift ~0.12 (variable) via assumption A17.", "A16, A17", overlap_txt(i, j, {"event"})))
for lab, s, nw, effs in EXC:
    i0 = exc_idx[lab][0]; j0 = i0 + nw - 1
    desc = {"Distribution disruption (synthetic)": ("Short regional distribution interruption reduces fulfilled sales, with partial recovery.", "Week 1 log effect ~N(-0.20,0.05); week 2 ~N(-0.08,0.04)."),
            "Batch-release supply interruption (synthetic)": ("Delayed batch release causes a supply interruption; Stockout_Flag forced to 1.", "Severe fill-ratio suppression ~Beta(4,4) (mean ~0.5)."),
            "Public-health advisory demand surge (synthetic)": ("Short-lived demand surge from heightened public-health attention outside the seasonal window.", "Week 1 log effect ~N(+0.14,0.05); week 2 ~N(+0.09,0.04).")}[lab]
    ev_rows.append((dates[i0], dates[j0], lab, "Exceptional one-off event", "Exceptional_Event", "Synthetic (NOT a verified Abbott incident)", desc[0], desc[1], "A22, A23",
                    overlap_txt(i0, j0, {"exc"}) + (" Stockout overlap by construction." if "Batch" in lab else "")))
for (i, j) in runs(stock == 1):
    ev_rows.append((dates[i], dates[j], "Stockout episode", "Stockout", "Stockout_Flag", "Synthetic", f"{j - i + 1}-week synthetic stockout.",
                    "Observed demand = latent x fill ratio ~Beta(6,3) (random per week); lost sales unknown.", "A20, A21", overlap_txt(i, j, {"stock"})))
for k, (rid, s, p_) in enumerate(PRICE_REGIMES):
    prev = PRICE_REGIMES[k - 1][2] if k else None
    ev_rows.append((pd.Timestamp(s), None, f"Price regime {rid} begins (PKR {p_})", "Price-regime change", "Price / Price_Regime_ID", "Synthetic (NOT an actual Abbott price or DRAP approval)",
                    "Initial regime." if prev is None else f"Illustrative step from PKR {prev} to PKR {p_} ({(p_ / prev - 1) * 100:.1f}%).",
                    "Weak negative price association; confounded with time.", "A08, A09, A12; context S6\u2013S8", "Regime changes are not placed in promo-specific weeks by design."))
for (i, j) in runs(promo == 1):
    ev_rows.append((dates[i], dates[j], f"Promotion campaign (depth {depth[i]:.3f})", "Promotion", "Promo_Flag / Promo_Depth", "Synthetic", f"{j - i + 1}-week trade-incentive campaign.",
                    "Modest variable uplift (A15).", "A13\u2013A15", overlap_txt(i, j, {"promo"})))
ev_rows.sort(key=lambda r_: (r_[0], r_[3]))
ev_rows += [
 ("19-May-2023", None, "S.R.O. 595(I)/2023 one-time CPI-based MRP dispensation", "Public regulatory context", "Price (context only)", "Public source (official notification text seen)", "Federal Government notification enabling one-time MRP increases (caps 14% essential / 20% others).", "None applied to data; context only.", "README S6", "Precedes the series."),
 ("Feb 2024", None, "Deregulation of prices of non-essential medicines (SRO 228(I)/2024 per later press)", "Public regulatory context", "Price (context only)", "Public source (secondary; original not opened)", "Government approved removing MRP controls on drugs outside the NEML.", "Motivates occasional, firm-initiated price steps.", "README S7\u2013S9", "Just before the series start."),
 ("2025", None, "Company-reported zinc-deficiency awareness activity for Surbex Z", "Public company context", "None (not mapped)", "Public source (Annual Report 2025, p.18)", "Qualitative mention of a disease-awareness campaign.", "NOT mapped to Promo_Flag or Marketing_Spend.", "README S1", "Context only."),
]
er = 5
EV_FIRST = er
for rv in ev_rows:
    for j, v in enumerate(rv):
        c = put(EL, f"{chr(65 + j)}{er}", v.to_pydatetime() if isinstance(v, pd.Timestamp) else v, border=True)
        if j < 2 and isinstance(v, pd.Timestamp): c.number_format = "dd-mmm-yyyy"
    er += 1
EV_LAST = er - 1
# exceptional-event audit table
er += 1
put(EL, f"A{er}", "Exceptional-event definitions used by audit test T16 (labels must equal Synthetic_Data!K)", f_bold, fill_sec); er += 1
header_row(EL, er, ["Date_Start", "Date_End", "Label"]); er += 1
XE_FIRST = er
for lab, s, nw, _ in EXC:
    i0 = exc_idx[lab][0]
    put(EL, f"A{er}", dates[i0].to_pydatetime(), f_in, fmt="dd-mmm-yyyy", border=True)
    put(EL, f"B{er}", dates[i0 + nw - 1].to_pydatetime(), f_in, fmt="dd-mmm-yyyy", border=True)
    put(EL, f"C{er}", lab, f_in, border=True); er += 1
XE_LAST = er - 1
widths(EL, dict(A=14, B=14, C=44, D=24, E=24, F=34, G=48, H=44, I=24, J=44))

# ----------------------------------------------------------------------------------
# Forecast_Setup
# ----------------------------------------------------------------------------------
put(FS, "A1", "Forecast Setup (no accuracy results and no model winner are reported here)", f_title, wrap=False)
put(FS, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
header_row(FS, 4, ["Item", "Specification"])
fs = [
 ("Training period", "Weeks 1\u2013108: 11-Mar-2024 to 30-Mar-2026 (Synthetic_Data rows 3\u2013110). All model fitting, parameter selection and model choice use TRAIN only."),
 ("Holdout period", "Weeks 109\u2013120: 06-Apr-2026 to 22-Jun-2026 (rows 111\u2013122). Reserved for out-of-sample evaluation; descriptive only before then."),
 ("Forecast horizon", "12 weeks (matches the planning decision). Evaluate (a) a fixed-origin 12-week-ahead forecast issued at the end of week 108, and optionally (b) rolling one-step-ahead forecasts."),
 ("Benchmark candidates", "Naive; seasonal naive (only if a seasonal period such as 52 weeks is defensible \u2014 sample has only ~2.3 cycles); 4-week moving average; simple exponential smoothing with pre-specified alpha = 0.3 and alpha = 0.6; Holt's trend method; Holt-Winters/other seasonal method only if the data support it."),
 ("Existing Historical_Forecast", "A 4-week trailing mean of prior observed demand (one-step-ahead). It is a synthetic benchmark generated before the series was analysed; it is NOT a candidate winner and was not chosen for accuracy."),
 ("Model assumptions to state", "Additive vs multiplicative structure; whether trend/seasonality are included and why; treatment of Event_Flag windows; treatment of stockout and exceptional-event weeks (keep, flag, or adjust \u2014 document the choice before looking at holdout results)."),
 ("Evaluation metrics (to calculate later)", "MAE, RMSE, bias (mean error), MAPE/sMAPE (guard against small denominators), MASE vs naive, and prediction-interval coverage if intervals are produced."),
 ("Leakage-prevention rules", "(1) Fit on TRAIN only. (2) Forecast for week t may use only data from weeks < t (or < 109 for a fixed-origin holdout forecast). (3) Do not tune smoothing parameters, seasonality or features on the holdout. (4) Freeze the model choice before computing holdout errors. (5) Do not regenerate or edit the data in response to results."),
 ("Stockout caveat", "Observed demand is censored in Stockout_Flag=1 weeks; errors in those weeks may reflect supply, not forecast quality. Report metrics with and without stockout/exceptional weeks, and do not treat observed sales as unconstrained demand."),
 ("Seasonality rules", "Models without seasonality are acceptable baselines. Seasonal methods must be justified (period, number of cycles, evidence in TRAIN) and compared against non-seasonal models; the holdout (Apr\u2013Jun) contains no Event_Flag weeks."),
 ("Planning decision link", "Translate forecasts into a 12-week commit-versus-flexible quantity using forecast uncertainty (e.g., error distribution from TRAIN rolling-origin evaluation). That recommendation is outside this dataset-generation task."),
]
for i, (a, b) in enumerate(fs):
    put(FS, f"A{5 + i}", a, f_bold, border=True); put(FS, f"B{5 + i}", b, border=True)
widths(FS, dict(A=34, B=120))

# ----------------------------------------------------------------------------------
# Data_Audit
# ----------------------------------------------------------------------------------
DA_HELP_HDR = 50; DA_H0 = 51
H = lambda col, i: f"Data_Audit!${col}${DA_H0}:${col}${DA_H0 + N - 1}"
put(DA, "A1", "Data Audit \u2014 quality-control checks (formula-driven where practical)", f_title, wrap=False)
put(DA, "A2", LABEL, Font(name=FN, size=9, bold=True, color="7F6000"), fill_lab, wrap=False)
put(DA, "A3", "Status rules: FAIL = critical integrity requirement violated; WARNING = structurally valid but needs review/disclosure; PASS = the defined rule was executed and satisfied. "
    "Analytical findings (insignificant coefficients, poor forecast accuracy) are not data-quality failures.", f_ital, wrap=False)
header_row(DA, 5, ["Audit_ID", "Test_Name", "Test_Purpose", "Validation_Rule", "Actual_Result", "Status", "Notes_or_Corrective_Action"])
pf = lambda col: rg(col)
def eq(v): return lambda e: f'=IF({e}={v},"PASS","FAIL")'
tests = []
def T(i, name, purpose, rule, result, status, notes=""):
    tests.append((i, name, purpose, rule, result, status, notes))
T("T01", "Exactly 120 weekly observations", "Count integrity", "COUNT(Week_Start_Date) = 120", f"=COUNT({pf('A')})", eq(f"{P['n_obs']}"))
T("T02", "Exactly 108 training observations", "Split integrity", "COUNTIF(Data_Split,'Train') = 108", f'=COUNTIF({pf("L")},"Train")', eq(f"{P['n_train']}"))
T("T03", "Exactly 12 holdout observations", "Split integrity", "COUNTIF(Data_Split,'Holdout') = 12", f'=COUNTIF({pf("L")},"Holdout")', eq(f"{P['n_obs']}-{P['n_train']}"))
T("T04", "Correct start and end dates", "Date range", "MIN = 11-Mar-2024 and MAX = 22-Jun-2026", f'=TEXT(MIN({pf("A")}),"yyyy-mm-dd")&" to "&TEXT(MAX({pf("A")}),"yyyy-mm-dd")',
  lambda e: f'=IF(AND(MIN({pf("A")})=DATE(2024,3,11),MAX({pf("A")})=DATE(2026,6,22)),"PASS","FAIL")')
T("T05", "Correct train/holdout boundaries", "Boundary dates and positions", "Train ends 30-Mar-2026; holdout runs 06-Apr-2026 to 22-Jun-2026; row 109 is Holdout",
  f'=TEXT(_xlfn.MAXIFS({pf("A")},{pf("L")},"Train"),"yyyy-mm-dd")&" | "&TEXT(_xlfn.MINIFS({pf("A")},{pf("L")},"Holdout"),"yyyy-mm-dd")&" to "&TEXT(_xlfn.MAXIFS({pf("A")},{pf("L")},"Holdout"),"yyyy-mm-dd")',
  lambda e: (f'=IF(AND(_xlfn.MAXIFS({pf("A")},{pf("L")},"Train")=DATE(2026,3,30),_xlfn.MINIFS({pf("A")},{pf("L")},"Holdout")=DATE(2026,4,6),'
             f'_xlfn.MAXIFS({pf("A")},{pf("L")},"Holdout")=DATE(2026,6,22),INDEX({pf("L")},108)="Train",INDEX({pf("L")},109)="Holdout",SUMPRODUCT(--({H("I", 0)}=1))=0),"PASS","FAIL")'))
T("T06", "Consecutive Monday dates", "Spacing and weekday", "All dates are Mondays and consecutive differences = 7 days (violations = 0)",
  f'=SUMPRODUCT(--(WEEKDAY({pf("A")},2)<>1))+SUMPRODUCT(--(Synthetic_Data!$A${R0 + 1}:$A${RN}-Synthetic_Data!$A${R0}:$A${RN - 1}<>7))', eq("0"))
T("T07", "No duplicate dates", "Uniqueness", "Dates appearing more than once = 0", f'=SUMPRODUCT(--(COUNTIF({pf("A")},{pf("A")})>1))', eq("0"))
T("T08", "No missing dates", "Completeness of calendar", "(max-min)/7+1 - count = 0", f'=(MAX({pf("A")})-MIN({pf("A")}))/7+1-COUNT({pf("A")})', eq("0"))
T("T09", "No missing required fields", "Completeness", "Blank cells in the 11 required columns = 0", f"=COUNTBLANK(Synthetic_Data!$A${R0}:$K${RN})", eq("0"))
T("T10", "Consistent product identity", "Single product", "All rows = 'Surbex-Z 30s'", f'=COUNTIF({pf("B")},"Surbex-Z 30s")', eq(f"{P['n_obs']}"))
T("T11", "Positive numeric demand", "Valid target", "All 120 demand values numeric and > 0", f'=COUNTIF({pf("C")},">0")', lambda e: f'=IF(AND({e}=120,COUNT({pf("C")})=120),"PASS","FAIL")')
T("T12", "Numeric, internally consistent price values", "Price validity", "All prices numeric, > 0, integer; one distinct price per regime", f'=COUNT({pf("E")})',
  lambda e: f'=IF(AND({e}=120,SUM({H("D", 0)})+SUM({H("F", 0)})=0,MIN({pf("E")})>0),"PASS","FAIL")', "Helper columns D (price vs regime table) and F (price constancy within regime).")
T("T13", "Valid 0/1 indicators", "Binary integrity", "Promo_Flag, Event_Flag, Stockout_Flag in {0,1}: invalid count = 0",
  f'=SUMPRODUCT(--({pf("F")}<>0),--({pf("F")}<>1))+SUMPRODUCT(--({pf("H")}<>0),--({pf("H")}<>1))+SUMPRODUCT(--({pf("J")}<>0),--({pf("J")}<>1))', eq("0"))
T("T14", "Zero Promo_Depth in non-promotional weeks", "Promo consistency", "Violations (depth<>0 when flag=0, or depth<=0 when flag=1) = 0",
  f'=SUMPRODUCT(({pf("F")}=0)*({pf("G")}<>0))+SUMPRODUCT(({pf("F")}=1)*({pf("G")}<=0))', eq("0"))
T("T15", "Price-regime dates consistent with price values", "Regime integrity", "Each week's Price and Price_Regime_ID equal the lookup from the regime input table (mismatches = 0)",
  f"=SUM({H('D', 0)})+SUM({H('E', 0)})+SUM({H('F', 0)})", eq("0"))
T("T16", "Correct labeling of exceptional events", "Event integrity", "Labelled weeks per event equal weeks in its date window; no other non-'None' labels",
  (f'=SUMPRODUCT(ABS(COUNTIF({pf("K")},Event_Log!$C${XE_FIRST}:$C${XE_LAST})-((Event_Log!$B${XE_FIRST}:$B${XE_LAST}-Event_Log!$A${XE_FIRST}:$A${XE_LAST})/7+1)))'
   f'+SUMPRODUCT(ABS(COUNTIFS({pf("K")},Event_Log!$C${XE_FIRST}:$C${XE_LAST},{pf("A")},">="&Event_Log!$A${XE_FIRST}:$A${XE_LAST},{pf("A")},"<="&Event_Log!$B${XE_FIRST}:$B${XE_LAST})-COUNTIF({pf("K")},Event_Log!$C${XE_FIRST}:$C${XE_LAST})))'
   f'+(COUNTIF({pf("K")},"<>None")-SUMPRODUCT(COUNTIF({pf("K")},Event_Log!$C${XE_FIRST}:$C${XE_LAST})))'), eq("0"))
T("T17", "Plausible variable ranges", "Pre-registered ranges", "Demand 20k\u2013100k; price 300\u2013700; marketing 0.3m\u201310m; promo depth <= 0.20 (violations = 0)",
  (f'=COUNTIF({pf("C")},"<"&{P["dem_lo"]})+COUNTIF({pf("C")},">"&{P["dem_hi"]})+COUNTIF({pf("E")},"<"&{P["price_lo"]})+COUNTIF({pf("E")},">"&{P["price_hi"]})'
   f'+COUNTIF({pf("I")},"<"&{P["mkt_lo"]})+COUNTIF({pf("I")},">"&{P["mkt_hi"]})+COUNTIF({pf("G")},">"&{P["depth_max"]})+COUNTIF({pf("D")},"<"&{P["dem_lo"]})+COUNTIF({pf("D")},">"&{P["dem_hi"]})'), eq("0"))
T("T18", "Historical forecast leakage check", "Critical leakage control", "Every forecast equals the rule applied to PRIOR weeks only (Excel recomputation, mismatches = 0); formula ranges end at row t-1",
  f"=SUM({H('H', 0)})", eq("0"), "Also executed in Python at build: altering actual[t:] never changed forecast[:t+1] (120/120 passes). Week-1 forecast = assumed prior planning figure.")
T("T19", "Correct calculation of summary statistics", "Cross-check", "Max |formula - Python reference| < 1e-6", f"=MAX(Summary_Stats!$D${XC_FIRST}:$D${XC_LAST})", lambda e: f'=IF({e}<0.000001,"PASS","FAIL")')
T("T20", "Data dictionary consistent with dataset", "Documentation", "Every dataset header appears in Data_Dictionary and counts match (unmatched = 0)",
  f"=SUMPRODUCT(--(COUNTIF(Data_Dictionary!$A$6:$A$20,Synthetic_Data!$A$2:$O$2)=0))", lambda e: f'=IF(AND({e}=0,COUNTA(Data_Dictionary!$A$6:$A$20)=COUNTA(Synthetic_Data!$A$2:$O$2)),"PASS","FAIL")')
T("T21", "Mandatory synthetic-data label present", "Labeling", "README and Synthetic_Data!A1 equal the exact mandatory label",
  f'=IF(AND(EXACT({LABEL_CELL},"{LABEL}"),EXACT(Synthetic_Data!$A$1,"{LABEL}")),1,0)', eq("1"))
T("T22", "Public calibration sources present and traceable", "Source traceability", "All 10 required fields populated for every source and every URL starts with http (blanks = 0)",
  f'=SUMPRODUCT(--(LEN(README!$A${SRC_FIRST}:$J${SRC_LAST})=0))+({SRC_LAST - SRC_FIRST + 1}-SUMPRODUCT(--(LEFT(README!$F${SRC_FIRST}:$F${SRC_LAST},4)="http")))', eq("0"),
  "Traceability only; see T26 for verification status of the revenue figure.")
T("T23", "Documented assumptions present", "Assumption coverage", "All 11 required topics appear in Assumption_Log (topics covered = 11)",
  "=" + "+".join(f'(COUNTIF(Assumption_Log!$B${AL_FIRST}:$B${AL_LAST},"*{k}*")>0)' for k in ["Demand scale", "Trend", "Noise", "Pricing", "Price regimes", "Promotions", "Event periods", "Marketing expenditure", "Stockouts", "Exceptional events", "Historical forecast"]), eq("11"))
T("T24", "Training-only thresholds in descriptive comparisons", "Grouping integrity", "Threshold = median of TRAIN weeks; Marketing_Group follows the rule for all rows (violations = 0)",
  f'=ABS({SS_THR}-MEDIAN({rg("I", *TR)}))+SUMPRODUCT(--((({pf("I")}<={SS_THR})*1)<>(({pf("O")}="Low")*1)))', eq("0"))
T("T25", "Workbook freeze/version documentation", "Version control", "README documents a version, a freeze-status field (mirroring Data_Audit overall status) and its meaning; status field is non-blank",
  f'={VERSION_CELL}&" | freeze status field present in README (mirrors Data_Audit!B43)"',
  lambda e: f'=IF(AND({VERSION_CELL}<>"",README!$A${RMAP["Freeze status"]}="Freeze status",LEN(README!$B${RMAP["Freeze status meaning"]})>20),"PASS","FAIL")',
  "Not circular: tests presence of documentation, not the status value. Allowed values: DRAFT / AUDIT FAILED / READY TO FREEZE / FROZEN.")
# warning-type tests
T("T26", "Company net-sales figure verified at original source", "Calibration verification", "WARNING unless the revenue source is marked independently verified (Yes)",
  f"={REV_VER_CELL}", lambda e: f'=IF(LEFT({e},3)="Yes","PASS","WARNING")', "FY2025 PKR 75.40bn corroborated by secondary sources only; context use only.")
T("T27", "Predictor correlation / multicollinearity", "Regression readiness", "WARNING if max |r| among 4 predictors > 0.70 or max VIF > 5 (TRAIN)",
  f'="max|r|="&TEXT({MAXR_CELL},"0.000")&"; maxVIF="&TEXT({MAXVIF_CELL},"0.000")', lambda e: f'=IF(OR({MAXR_CELL}>{P["corr_thr"]},{MAXVIF_CELL}>{P["vif_thr"]}),"WARNING","PASS")')
T("T28", "Price\u2013time confounding", "Interpretation risk", "WARNING if |corr(Price, Week_Number)| > 0.5 (TRAIN)", f"={PT_CELL}", lambda e: f'=IF(ABS({e})>0.5,"WARNING","PASS")', "Price coefficient is an association only.")
T("T29", "Limited price variation", "Regression readiness", "WARNING if fewer distinct TRAIN price values than the register threshold (10)", f"=SUMPRODUCT(1/COUNTIF({rg('E', *TR)},{rg('E', *TR)}))",
  lambda e: f'=IF({e}<{P["price_distinct_min"]},"WARNING","PASS")', "Recorded as a limitation; not manipulated away.")
T("T30", "Small descriptive group sizes", "Descriptive comparisons", "WARNING if any comparison group has n < 10", f"=MIN(Summary_Stats!$D${CMP_FIRST}:$D${CMP_LAST})", lambda e: f'=IF({e}<{P["small_n"]},"WARNING","PASS")')
T("T31", "Holdout coverage of seasonal events", "Evaluation design", "WARNING if holdout contains no Event_Flag weeks", f'=SUM({rg("H", *HO)})', lambda e: f'=IF({e}=0,"WARNING","PASS")', "Event effects cannot be assessed out-of-sample.")
T("T32", "Realised promotion rate vs starting design range", "Realism disclosure", "WARNING if realised promotion rate is outside the 15%\u201320% starting design range (rate was NOT forced)",
  f"=Summary_Stats!$B${S['pr']}", lambda e: f'=IF(OR({e}<0.15,{e}>0.2),"WARNING","PASS")', "Realised rate is the output of the seeded process; no regeneration or adjustment was performed to hit the target.")
T("T33", "Stockout weeks vs lowest-demand weeks", "Realism disclosure", "WARNING if every stockout week is among the k lowest-demand weeks (k = number of stockout weeks)",
  f'=SUMPRODUCT(({pf("J")}=1)*({pf("C")}<=SMALL({pf("C")},SUM({pf("J")}))))', lambda e: f'=IF({e}=SUM({pf("J")}),"WARNING","PASS")',
  "Arises from a random fill ratio with very few stockout weeks; not engineered, not corrected. Stockout weeks are NOT guaranteed to be the lowest in general.")
assert len(tests) <= 34
DA_FIRST = 6
for k, (i, name, purpose, rule, res, st, notes) in enumerate(tests):
    r_ = DA_FIRST + k
    put(DA, f"A{r_}", i, border=True); put(DA, f"B{r_}", name, border=True); put(DA, f"C{r_}", purpose, border=True); put(DA, f"D{r_}", rule, border=True)
    put(DA, f"E{r_}", res, fmt="General", border=True); put(DA, f"F{r_}", st(f"E{r_}"), f_bold, border=True); put(DA, f"G{r_}", notes, border=True)
DA_LAST = DA_FIRST + len(tests) - 1
ST = f"$F${DA_FIRST}:$F${DA_LAST}"
for txt, fill in (("PASS", fill_pass), ("WARNING", fill_warn), ("FAIL", fill_fail), ("NOT TESTED", fill_warn)):
    DA.conditional_formatting.add(f"F{DA_FIRST}:F{DA_LAST}", FormulaRule(formula=[f'$F{DA_FIRST}="{txt}"'], fill=fill))
put(DA, "A40", "Audit conclusion", f_bold, fill_sec, wrap=False)
put(DA, "A41", "Critical FAIL count", f_bold, border=True); put(DA, "B41", f'=COUNTIF({ST},"FAIL")', border=True)
put(DA, "A42", "WARNING count / PASS count", f_bold, border=True); put(DA, "B42", f'=COUNTIF({ST},"WARNING")&" warnings / "&COUNTIF({ST},"PASS")&" passes"', border=True)
put(DA, "A43", "Overall status", f_bold, border=True)
put(DA, "B43", f'=IF(B41>0,"AUDIT FAILED",IF(COUNTIF({ST},"NOT TESTED")>0,"DRAFT","READY TO FREEZE"))', Font(name=FN, size=11, bold=True), border=True)
put(DA, "A44", "Conclusion", f_bold, border=True)
put(DA, "B44", f'=IF(B41>0,"Critical integrity failures present: correct and re-run before freezing.","No critical integrity FAIL. Eligible for formal freezing (NOT yet frozen). "&COUNTIF({ST},"WARNING")&" warning(s) are disclosure items, not defects.")', border=True)
put(DA, "A45", "Defect/correction log", f_bold, border=True)
put(DA, "B45", "None. The series was generated once (seed 353); no observation was edited or regenerated after generation.", border=True)
DA.conditional_formatting.add("B43", FormulaRule(formula=['$B$43="READY TO FREEZE"'], fill=fill_pass))
DA.conditional_formatting.add("B43", FormulaRule(formula=['$B$43="AUDIT FAILED"'], fill=fill_fail))
# helper table
put(DA, f"A{DA_HELP_HDR - 1}", "Audit helper table (one row per week; formulas independent of the data generation)", f_bold, fill_sec, wrap=False)
header_row(DA, DA_HELP_HDR, ["Week_Number", "Week_Start_Date", "Expected_Price (regime table)", "Price_Mismatch", "Regime_ID_Mismatch", "Price_Constancy_Mismatch (price vs regime mean)",
                             "Expected_Forecast (prior weeks only)", "Forecast_Mismatch", "Split_vs_Position_Mismatch"])
for i in range(N):
    h = DA_H0 + i; d = R0 + i
    put(DA, f"A{h}", f"=Synthetic_Data!$M${d}", fmt="0"); put(DA, f"B{h}", f"=Synthetic_Data!$A${d}", fmt="dd-mmm-yyyy")
    put(DA, f"C{h}", f"=LOOKUP(B{h},{REG_STARTS},{REG_PRICES})", fmt="#,##0")
    put(DA, f"D{h}", f"=IF(Synthetic_Data!$E${d}=C{h},0,1)")
    put(DA, f"E{h}", f"=IF(Synthetic_Data!$N${d}=LOOKUP(B{h},{REG_STARTS},{REG_IDS}),0,1)")
    put(DA, f"F{h}", f"=IF(Synthetic_Data!$E${d}=AVERAGEIFS({rg('E')},{rg('N')},Synthetic_Data!$N${d}),0,1)")
    if i == 0: put(DA, f"G{h}", f"={P['fc_init']}", fmt="#,##0")
    else:
        a_start = max(R0, d - 4)
        put(DA, f"G{h}", f"=ROUND(AVERAGE(Synthetic_Data!$C${a_start}:$C${d - 1}),0)", fmt="#,##0")
    put(DA, f"H{h}", f"=IF(Synthetic_Data!$D${d}=G{h},0,1)")
    put(DA, f"I{h}", f'=IF(Synthetic_Data!$L${d}=IF(A{h}<={P["n_train"]},"Train","Holdout"),0,1)')
# T05 used H("I",0) as split-vs-position mismatches
widths(DA, dict(A=14, B=36, C=30, D=52, E=26, F=14, G=52, H=16, I=22))

wb.move_sheet("README", offset=0)
wb.save(OUT)

# ---- save for reporting ----
df.to_csv(OUT.replace(".xlsx", "_python_check.csv"), index=False)
info = dict(leak_pass=leak_pass, seed=SEED, mean=float(a_all.mean()), n_promo=int(promo.sum()), n_event=int(event.sum()), n_stock=int(stock.sum()))
print(json.dumps(info))

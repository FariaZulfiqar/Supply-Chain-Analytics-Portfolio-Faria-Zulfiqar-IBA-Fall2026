# STEP 1: fit/initialise every model on TRAINING rows only (weeks 1-108). Holdout actuals are dropped before any computation.
import pandas as pd, numpy as np, json
from scipy.optimize import minimize
SRC='/root/.claude/uploads/99de192a-e88f-5fa0-a123-7cec3bd55247/6a686890-MGT353_SurbexZ_Synthetic_Dataset_v1.0.xlsx'
full=pd.read_excel(SRC,sheet_name='Synthetic_Data',header=1,keep_default_na=False)
tr=full.iloc[:108][['Week_Number','Week_Start_Date','Actual_Demand']].copy()   # holdout rows are NOT carried forward
assert (full.Data_Split.iloc[:108]=='Train').all() and tr.Week_Number.max()==108
dates_h=full.Week_Start_Date.iloc[108:].tolist(); del full
A=tr.Actual_Demand.to_numpy(float); n=len(A); H=12
naive=[A[-1]]*H
ma=list(A[-4:]); 
for h in range(H): ma.append(np.mean(ma[-4:]))
ma4=ma[4:]
def ses(alpha):
    l=A[0]; 
    for a in A: l=alpha*a+(1-alpha)*l
    return [l]*H
w=np.arange(1,11); b0,l0=np.polyfit(w,A[:10],1)   # init from OLS on first 10 training weeks: level at week 0, slope
def holt_run(al,be):
    l,b=l0,b0; sse=0
    for a in A:
        f=l+b; sse+=(a-f)**2
        ln=al*a+(1-al)*f; b=be*(ln-l)+(1-be)*b; l=ln
    return sse,l,b
best=None
for al0 in (0.05,0.2,0.5,0.8):
  for be0 in (0.01,0.05,0.2,0.5):
    r=minimize(lambda p:holt_run(*p)[0],[al0,be0],method='L-BFGS-B',bounds=[(1e-4,0.9999)]*2)
    if best is None or r.fun<best.fun-1e-9: best=r
al,be=best.x; sse,lN,bN=holt_run(al,be)
# constraint check beta<=alpha (usual admissible region)
print('holt',al,be,sse,lN,bN,best.success)
holt=[lN+(h+1)*bN for h in range(H)]
out=dict(dates=[str(d)[:10] for d in dates_h],naive=naive,ma4=ma4,ses03=ses(0.3),ses06=ses(0.6),holt=holt,holt_alpha=al,holt_beta=be,holt_l0=l0,holt_b0=b0,holt_sse=sse,holt_lN=lN,holt_bN=bN,holt_conv=bool(best.success),last_train_date=str(tr.Week_Start_Date.iloc[-1])[:10])
json.dump(out,open('frozen_forecasts.json','w'),indent=1)
for k in ('naive','ma4','ses03','ses06','holt'): print(k,np.round(out[k],1))
